#include<iostream>
#include<cstdlib>
#include<fstream>
#include<string>
#include<bits/stdc++.h>
#include "1905098_Symbol_Table.h"
using namespace std;

class Helper
{



public:

    string name;
    int start_line;
    int end_line;
    string parse_tree;
    string type;
    string value;
    string returnType;
    vector<Helper*> childVector;
    bool isLeaf;

    Helper()
    {
        parse_tree = "";
    }
    Helper(string name)
    {
        parse_tree = "";
        this->name = name;
        parse_tree += name;
        isLeaf = false;
    }
    void setVector(vector<Helper*> v)
    {
        this->childVector = v;
    }
    void add(Helper* helper)
    {
        this->childVector.push_back(helper);
    }
    ~Helper()
    {

    }
    void print()
    {


    }


};