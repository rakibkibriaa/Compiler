%{
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cmath>

#include "1905098_Helper.h"

using namespace std;

int yyparse(void);
int yylex(void);

extern FILE *yyin; 

extern int line_count;

ofstream parseFile;
ofstream errorFile;
ofstream logFile;

SymbolTable *symboltable;
FILE* fp;



int error_count = 0;

struct combined {

	Helper* helper;
	SymbolInfo* symbol;

} temp_value;


vector<combined> temp_parameter;

vector<combined> temp_variable;

vector<string> temp_arguments;

vector<string> func_params;

void yyerror(char *s)
{
	

}

void print_parse_tree(Helper* helper,int depth)
{
   
    for(int i=0;i<depth;i++)
    {
        parseFile<<" ";
    }

    parseFile<<helper->name;
    parseFile<<"\t";

    if(helper->isLeaf == false)
    {
        parseFile<<"<Line: ";
        parseFile<<helper->start_line;
        parseFile<<"-";
        parseFile<<helper->end_line;
        parseFile<<">";
    }
    else
    {
        parseFile<<"<Line: ";
        parseFile<<helper->start_line;
        parseFile<<">";

    }
    
    parseFile<<endl;

    if(helper->isLeaf)
    {
        return;
    }

    for(int i=0;i<helper->childVector.size();i++)
    {
        print_parse_tree(helper->childVector[i],depth + 1);
    }
    
}
void delete_tree(Helper* helper)
{
	
   for(int i=0;i<helper->childVector.size();i++)
   {
	  delete_tree(helper->childVector[i]);
   }
   helper->childVector.clear();

   delete helper;

}




%}


%union 
{
	

	struct
	{
		SymbolInfo* symbol;
		Helper* helper;

	} value;
	

}




%token <value> CONST_INT CONST_FLOAT ID LOGICOP RELOP ADDOP MULOP
%token <value.helper> INT DO CHAR DOUBLE CONTINUE
%token <value.helper> FLOAT VOID IF ELSE FOR WHILE PRINTLN RETURN LOWER_THAN_ELSE
%token <value.helper> ASSIGNOP NOT INCOP DECOP
%token <value.helper> LPAREN RPAREN LCURL RCURL LSQUARE RSQUARE COMMA SEMICOLON 


%type <value.helper> start program unit var_declaration func_declaration func_definition declaration_list type_specifier parameter_list compound_statement
%type <value.helper> statements statement expression_statement expression variable logic_expression rel_expression simple_expression term
%type <value.helper> unary_expression factor argument_list arguments 


%nonassoc LOWER_THAN_ELSE
%nonassoc ELSE

%%

start : program
	{

		
		$$ = new Helper("start : program ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $1->end_line;


        $$ -> add($1);
   

        print_parse_tree($$,0);


		logFile<<$$->name<<endl;

		delete_tree($$);
		
	}
	;

program : program unit 
	{
		$$ = new Helper("program : program unit ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $2->end_line;
		
		$$ -> add($1);
        $$ -> add($2);
      
		
		logFile<<$$->name<<endl;
	}
	| unit
	{
		$$ = new Helper("program : unit ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $1->end_line;
		
		$$ -> add($1);
 
		
		logFile<<$$->name<<endl;

	}
	;
	
unit : var_declaration 
	 {
		$$ = new Helper("unit : var_declaration ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $1->end_line;
		
		$$ -> add($1);


		logFile<<$$->name<<endl;
	
	 }
     | func_declaration
	 {
		$$ = new Helper("unit : func_declaration ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $1->end_line;
		
		$$ -> add($1);


		logFile<<$$->name<<endl;
	 }
     | func_definition
	 {
		$$ = new Helper("unit : func_definition ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $1->end_line;

		$$ -> add($1);
   

		logFile<<$$->name<<endl;
	 }
     ;
     
func_declaration : type_specifier ID LPAREN parameter_list RPAREN SEMICOLON 
		{
			$$ = new Helper("func_declaration : type_specifier ID LPAREN parameter_list RPAREN SEMICOLON ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $6->end_line;
			
			$$ -> add($1);
            $$ -> add($2.helper);
            $$ -> add($3);
            $$ -> add($4);
            $$ -> add($5);
            $$ -> add($6);
          
            
			SymbolInfo* symbol = new SymbolInfo($2.symbol->getName(),"FUNCTION");

			for(int i=0;i<temp_parameter.size();i++)
			{
				symbol->param_type.push_back(temp_parameter[i].symbol->getType());
			}

			symbol->additionalType = $1->type;
			symbol->isdefined = false;

			if(symboltable->Insert(symbol))
			{
					//successfully inserted
			}
			else
			{
				
				//2 cases; symbol table has symbol which is fuction type or not 

				SymbolInfo* lookupSymbol = symboltable->lookup(symbol->getName());

				if(lookupSymbol->getType() == "FUNCTION")
				{
					errorFile<<"Line# "<<$2.helper->start_line<<": '"<<lookupSymbol->getName()<<"' function has multiple declaration"<<endl;
					error_count++;
				}
				else
				{
					errorFile<<"Line# "<<$2.helper->start_line<<": '"<<lookupSymbol->getName()<<"' redeclared as different kind of symbol"<<endl;
					error_count++;
				}

				delete symbol;


			}

			temp_parameter.clear();

			logFile<<$$->name<<endl;

		}
		| type_specifier ID LPAREN RPAREN SEMICOLON 
		{
			$$ = new Helper("func_declaration : type_specifier ID LPAREN RPAREN SEMICOLON ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $5->end_line;
			
			$$ -> add($1);
            $$ -> add($2.helper);
            $$ -> add($3);
            $$ -> add($4);
            $$ -> add($5);



			SymbolInfo* symbol = new SymbolInfo($2.symbol->getName(),"FUNCTION");


			symbol->additionalType = $1->type;
			symbol->isdefined = false;

			if(symboltable->Insert(symbol))
			{
				//successfully inserted
			}
			else
			{
				//2 cases; symbol table has symbol which is fuction type or not 

				SymbolInfo* lookupSymbol = symboltable->lookup(symbol->getName());

				if(lookupSymbol->getType() == "FUNCTION")
				{
					errorFile<<"Line# "<<$2.helper->start_line<<": '"<<lookupSymbol->getName()<<"' function has multiple declaration"<<endl;
					
					
				}
				else
				{
					errorFile<<"Line# "<<$2.helper->start_line<<": '"<<lookupSymbol->getName()<<"' redeclared as different kind of symbol"<<endl;
					
				}
				error_count++;

				delete symbol;


			}

			
			logFile<<$$->name<<endl;
		}
		;
		 
func_definition : type_specifier ID LPAREN parameter_list RPAREN
{
				
	SymbolInfo* symbol = new SymbolInfo($2.symbol->getName(),"FUNCTION");


	for(int i=0;i<temp_parameter.size();i++)
	{
		symbol->param_type.push_back(temp_parameter[i].symbol->getType());
	}

	symbol->additionalType = $1->type;
	symbol->isdefined = true;

	if(symboltable->Insert(symbol))
	{
		//successfully inserted
	}
	else
	{
		//already exists in symbol table

		SymbolInfo* lookupSymbol = symboltable->lookup(symbol->getName());

		if(lookupSymbol->getType() == "FUNCTION")
		{
			if(lookupSymbol->isdefined == false) //declared but not defined
			{

				bool ok = true;

				
				if(temp_parameter.size() != lookupSymbol->param_type.size()) //parameter size
				{
					errorFile<<"Line# "<<$1->start_line<<": Conflicting types for '"<<lookupSymbol->getName()<<"'"<<endl;
					ok = false;
					error_count++;
				}

				if(lookupSymbol->additionalType != $1->type) // return type
				{
					ok = false;

					errorFile<<"Line# "<<$1->start_line<<": Conflicting types for '"<<lookupSymbol->getName()<<"'"<<endl;

					error_count++;
				}

				if(ok) // total parameters and return type is ok then check parameter types
				{
					for(int i=0;i<lookupSymbol->param_type.size();i++) // check parameter type
					{
						if(temp_parameter[i].symbol->getType() != lookupSymbol->param_type[i])
						{
							errorFile<<"Line# "<<$1->start_line<<": Conflicting types for '"<<lookupSymbol->getName()<<"' parameter "<<temp_parameter[i].symbol->getName()<<endl;
							ok = false;
							error_count++;

						}
					}
					
				}

				if(ok)
				{
					lookupSymbol->isdefined = true;
				}

				
			} 
			else //already defined
			{
				errorFile<<"Line# "<<$1->start_line<<": Multiple defination for '"<<lookupSymbol->getName()<<"'"<<endl;
				error_count++;
			}
		}
		else 
		{ 
			errorFile<<"Line# "<<$2.helper->start_line<<": '"<<lookupSymbol->getName()<<"' redeclared as different kind of symbol"<<endl;
			error_count++;
		}
		delete symbol;
	}
				
} 	
compound_statement 
		{
			$$ = new Helper("func_definition : type_specifier ID LPAREN parameter_list RPAREN compound_statement ");


			$$ -> start_line = $1->start_line;
			$$ -> end_line = $7->end_line;
			
			$$ -> add($1);
            $$ -> add($2.helper);
            $$ -> add($3);
            $$ -> add($4);
            $$ -> add($5);
            $$ -> add($7);
            

			/* check return type and return statement */

			if($1 -> type == "VOID" && $7 -> returnType != "")
			{
				errorFile<<"Line# "<<$1->start_line<<": retrun type is void but func is returning '"<<$7->returnType<<"'"<<endl;
				error_count++;
			}
			else if($1 -> type == "INT" && $7 -> returnType == "FLOAT")
			{
				errorFile<<"Line# "<<$1->start_line<<": Warning: possible loss of data in returning of FLOAT to INT"<<endl;
				error_count++;
			}
			else if($1 -> type != "VOID" && $7 -> returnType == "")
			{
				errorFile<<"Line# "<<$1->start_line<<": Warning: no data is returned from function"<<endl;
				error_count++;
			}  


			logFile<<$$->name<<endl;
			
		}
		| type_specifier ID LPAREN RPAREN 
		{
			

				SymbolInfo* symbol = new SymbolInfo($2.symbol->getName(),"FUNCTION");


				symbol->additionalType = $1->type;
				symbol->isdefined = true;

				if(symboltable->Insert(symbol))
				{
					//successfully inserted
				}
				else
				{
					SymbolInfo* lookupSymbol = symboltable->lookup(symbol->getName());

					if(lookupSymbol->getType() == "FUNCTION")
					{
						if(lookupSymbol->isdefined == false) //declared but not defined
						{

							bool ok = true;

							
							if(temp_parameter.size() != lookupSymbol->param_type.size())
							{
								errorFile<<"Line# "<<$1->start_line<<": Conflicting types for '"<<lookupSymbol->getName()<<"'"<<endl;
								ok = false;
								error_count++;
							}

							if(lookupSymbol->additionalType != $1->type)
							{
								ok = false;

								errorFile<<"Line# "<<$1->start_line<<": Conflicting types for '"<<lookupSymbol->getName()<<"'"<<endl;
								error_count++;
							}

							if(ok)
							{
								for(int i=0;i<lookupSymbol->param_type.size();i++) // check parameter type
								{
									if(temp_parameter[i].symbol->getType() != lookupSymbol->param_type[i])
									{
										errorFile<<"Line# "<<$1->start_line<<": Conflicting types for '"<<lookupSymbol->getName()<<"' parameter "<<temp_parameter[i].symbol->getName()<<endl;
										ok = false;
										error_count++;

									}
								}
								
							}

							if(ok)
							{
								lookupSymbol->isdefined = true;
							}							
						}
						else
						{
							errorFile<<"Line# "<<$1->start_line<<": Multiple defination for '"<<lookupSymbol->getName()<<"'"<<endl;
							error_count++;
						}
					}
					else
					{
						errorFile<<"Line# "<<$2.helper->start_line<<": '"<<lookupSymbol->getName()<<"' redeclared as different kind of symbol"<<endl;
						error_count++;
					}

					delete symbol;

				}
				
		} 
		compound_statement
		{
			$$ = new Helper("func_definition : type_specifier ID LPAREN RPAREN compound_statement ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $6->end_line;
			
			$$ -> add($1);
            $$ -> add($2.helper);
            $$ -> add($3);
            $$ -> add($4);
            $$ -> add($6);
           


			/* check return type and return statement */

			if($1 -> type == "VOID" && $6 -> returnType != "")
			{
				errorFile<<"Line# "<<$1->start_line<<": retrun type is void but func is returning '"<<$6->returnType<<"'"<<endl;
				error_count++;
			}
			else if($1 -> type == "INT" && $6 -> returnType == "FLOAT")
			{
				errorFile<<"Line# "<<$1->start_line<<": Warning: possible loss of data in returning of FLOAT to INT"<<endl;
				error_count++;
			}
			else if($1 -> type != "VOID" && $6 -> returnType == "")
			{
				errorFile<<"Line# "<<$1->start_line<<": Warning: no data is returned from function"<<endl;
				error_count++;
			}  

			
			logFile<<$$->name<<endl;
		}
 		;				


parameter_list : parameter_list COMMA type_specifier ID
		{
			$$ = new Helper("parameter_list : parameter_list COMMA type_specifier ID ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $4.helper->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
            $$ -> add($3);
            $$ -> add($4.helper);
       


			SymbolInfo* symbol = new SymbolInfo($4.symbol->getName(),$3->type);

			temp_value.symbol = symbol;
			temp_value.helper =  $4.helper;

			temp_parameter.push_back(temp_value);

			logFile<<$$->name<<endl;

	
		}
		| parameter_list COMMA type_specifier
		{
			$$ = new Helper("parameter_list : parameter_list COMMA type_specifier ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $3->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
            $$ -> add($3);



			SymbolInfo* symbol = new SymbolInfo("",$3->type);

			temp_value.symbol = symbol;
			temp_value.helper =  $3;

			temp_parameter.push_back(temp_value);
			logFile<<$$->name<<endl;

			
		}
 		| type_specifier ID
		{
			$$ = new Helper("parameter_list : type_specifier ID ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $2.helper->end_line;
			
			$$ -> add($1);
            $$ -> add($2.helper);
            



			SymbolInfo* symbol = new SymbolInfo($2.symbol->getName(),$1->type);
			temp_value.symbol = symbol;
			temp_value.helper =  $2.helper;

			temp_parameter.push_back(temp_value);
			
			logFile<<$$->name<<endl;
		}
		| type_specifier
		{
			$$ = new Helper("parameter_list : type_specifier ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);

			SymbolInfo* symbol = new SymbolInfo("",$1->type);
			temp_value.symbol = symbol;
			temp_value.helper =  $1;

			temp_parameter.push_back(temp_value);
			
			logFile<<$$->name<<endl;
		}
 		;

 		
compound_statement : LCURL ENTER_SCOPE statements RCURL
			{
				
				$$ = new Helper("compound_statement : LCURL statements RCURL ");

				$$ -> start_line = $1->start_line;
				$$ -> end_line = $4->end_line;
				
				$$ -> add($1);
                $$ -> add($3);
                $$ -> add($4);


				
				
				$$ -> returnType = $3 -> returnType;

				
				logFile<<$$->name<<endl;

				symboltable -> Print_All_Scope_Table();

				symboltable -> Exit_Scope();

				

			}
 		    | LCURL ENTER_SCOPE RCURL
			{
				
				$$ = new Helper("compound_statement : LCURL RCURL ");

				$$ -> start_line = $1->start_line;
				$$ -> end_line = $3->end_line;
				
				$$ -> add($1);
               
                $$ -> add($3);

				logFile<<$$->name<<endl;
				symboltable -> Print_All_Scope_Table();
				symboltable -> Exit_Scope();
			
			}
 		    ;

ENTER_SCOPE : {

			symboltable -> Enter_Scope();

			
			for(int i=0;i<temp_parameter.size();i++)
			{
				
				SymbolInfo* symbol = new SymbolInfo(temp_parameter[i].symbol->getName(),temp_parameter[i].symbol->getType());

				int line_count = temp_parameter[i].helper->start_line;

				

				if(symbol->getName() == "")
				{
					errorFile<<"Line# "<<line_count<<": No variable declared after type_specifier"<<symbol->getType()<<"'"<<endl;
					error_count++;
				}
				else
				{
					if(symboltable->Insert(symbol))
					{
						//successfully inserted
					}
					else
					{
						
						errorFile<<"Line# "<<line_count<<": Redefinition of parameter '"<<temp_parameter[i].symbol->getName()<<"'"<<endl;
						error_count++;

						delete symbol;
					}
				}
				
			}

			temp_parameter.clear();
}
;

var_declaration : type_specifier declaration_list SEMICOLON 
{
		
		$$ = new Helper("var_declaration : type_specifier declaration_list SEMICOLON ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $3->end_line;
		
		$$ -> add($1);
        $$ -> add($2);
        $$ -> add($3);

		$$ ->type = $1 -> type;



		/* add all variables to symboltable */
		
		for(int i=0;i<temp_variable.size();i++)
		{

			
			SymbolInfo* symbol = new SymbolInfo(temp_variable[i].symbol->getName(),temp_variable[i].symbol->getType());


			if($1 ->type == "VOID")
			{
				errorFile<<"Line# "<<temp_variable[i].helper->start_line<<": Variable or field '"<<temp_variable[i].symbol->getName()<<"' declared void"<<endl;
				error_count++;
			}
			else // try insert to symbol table
			{
				if(symbol->getType() == "")
				{
					symbol->setType($1 -> type);
				}
				else if(symbol->getType() == "ARRAY")
				{
					symbol -> additionalType = $1 -> type;
				}



				if(symboltable->Insert(symbol))
				{
					//successfully inserted
				}
				else  //already inserted in symbol table
				{
					SymbolInfo* lookupSymbol = symboltable->lookup(symbol->getName());

					if(lookupSymbol->getType() != "ARRAY") 
					{
						if(lookupSymbol->getType() != symbol->getType())
						{
							errorFile<<"Line# "<<temp_variable[i].helper->start_line<<": Conflicting types for '"<<lookupSymbol->getName()<<"'"<<endl;
							error_count++;
						}
						else
						{
							errorFile<<"Line# "<<temp_variable[i].helper->start_line<<": Multiple declaration for '"<<lookupSymbol->getName()<<"'"<<endl;
							error_count++;
						}
					}
					else
					{
						if(lookupSymbol->additionalType != symbol->additionalType)
						{
							errorFile<<"Line# "<<temp_variable[i].helper->start_line<<": Conflicting types for '"<<lookupSymbol->getName()<<"'"<<endl;
							error_count++;
						}
						else
						{
							errorFile<<"Line# "<<temp_variable[i].helper->start_line<<": Multiple declaration for '"<<lookupSymbol->getName()<<"'"<<endl;
							error_count++;
						}
					}

					delete symbol;
				}
			}

			
		}

		temp_variable.clear();

		logFile<<$$->name<<endl;
}
;
 		 
type_specifier : INT 
		{
			$$ = new Helper("type_specifier : INT ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
           

			$$ -> type = "INT";

			logFile<<$$->name<<endl;



		}
 		| FLOAT
		{
			$$ = new Helper("type_specifier : FLOAT ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
          

			$$ -> type = "FLOAT";

			logFile<<$$->name<<endl;
			 
		}
 		| VOID
		{
			$$ = new Helper("type_specifier : VOID ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
           
          

			$$ -> type = "VOID";


			logFile<<$$->name<<endl;
		}
 		;
 		
declaration_list : declaration_list COMMA ID 
			{
				$$ = new Helper("declaration_list : declaration_list COMMA ID ");
				
				$$ -> start_line = $1->start_line;
				$$ -> end_line = $3.helper->end_line;
				
				$$ -> add($1);
                $$ -> add($2);
                $$ -> add($3.helper);
             


				SymbolInfo* symbol = $3.symbol;
				symbol->setType("");  					// type set to null, later it will be initialized in var_declaration part

				temp_value.symbol = symbol;
				temp_value.helper =  $3.helper;

				temp_variable.push_back(temp_value);

			
				logFile<<$$->name<<endl;
				
				
			}

 		  | declaration_list COMMA ID LSQUARE CONST_INT RSQUARE 
			{
				$$ = new Helper("declaration_list : declaration_list COMMA ID LSQUARE CONST_INT RSQUARE ");

				$$ -> start_line = $1->start_line;
				$$ -> end_line = $6->end_line;
				
				$$ -> add($1);
                $$ -> add($2);
                $$ -> add($3.helper);
                $$ -> add($4);
                $$ -> add($5.helper);
                $$ -> add($6);
           

				SymbolInfo* symbol = $3.symbol;
				symbol->setType("ARRAY");
				temp_value.symbol = symbol;
				temp_value.helper =  $3.helper;


				temp_variable.push_back(temp_value);
				
				logFile<<$$->name<<endl;
			}
 		  | ID 
		  {
			 	$$ = new Helper("declaration_list : ID ");

			 	$$ -> start_line = $1.helper->start_line;
				$$ -> end_line = $1.helper->end_line;
				
				$$ -> add($1.helper);
    

				SymbolInfo* symbol = $1.symbol;
				symbol->setType("");
				temp_value.symbol = symbol;
				temp_value.helper =  $1.helper;


				temp_variable.push_back(temp_value);

				logFile<<$$->name<<endl;
			 
		  }
 		  | ID LSQUARE CONST_INT  RSQUARE 
		  {
				$$ = new Helper("declaration_list : ID LSQUARE CONST_INT RSQUARE ");


				$$ -> start_line = $1.helper->start_line;
				$$ -> end_line = $4->end_line;
				
				$$ -> add($1.helper);
                $$ -> add($2);
                $$ -> add($3.helper);
                $$ -> add($4);
           


				SymbolInfo* symbol = $1.symbol;
				symbol->setType("ARRAY");
				temp_value.symbol = symbol;
				temp_value.helper =  $1.helper;
				temp_variable.push_back(temp_value);

				logFile<<$$->name<<endl;

		  }
 		  ;
 		  
statements : statement
		{
			$$ = new Helper("statements : statement ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
       

			$$ -> returnType = $1 -> returnType;

			logFile<<$$->name<<endl;
		}
	   | statements statement
	   {
		   $$ = new Helper("statements : statements statement ");

		  	$$ -> start_line = $1->start_line;
			$$ -> end_line = $2->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
      

		   $$ -> returnType = $2 -> returnType;

		   logFile<<$$->name<<endl;
	   }
	   ;
	   
statement : var_declaration
		{
		    $$ = new Helper("statement : var_declaration ");

		    $$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
           

		   logFile<<$$->name<<endl;
		
		}
	  | expression_statement
	   {
		    $$ = new Helper("statement : expression_statement ");

		    $$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
         

		   logFile<<$$->name<<endl;
		 
	   }
	  | compound_statement
	  {
		   $$ = new Helper("statement : compound_statement ");

		    $$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;

			$$ -> add($1);
       

		   logFile<<$$->name<<endl;
	  }
	  | FOR LPAREN expression_statement expression_statement expression RPAREN statement
	  {
		    $$ = new Helper("statement : FOR LPAREN expression_statement expression_statement expression RPAREN statement ");


			$$ -> start_line = $1->start_line;
			$$ -> end_line = $7->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
            $$ -> add($3);
            $$ -> add($4);
            $$ -> add($5);
            $$ -> add($6);
            $$ -> add($7);
           


			logFile<<$$->name<<endl;
			

		   
	  }
	  | IF LPAREN expression RPAREN statement %prec LOWER_THAN_ELSE
	  {
			$$ = new Helper("statement : IF LPAREN expression RPAREN statement ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $5->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
            $$ -> add($3);
            $$ -> add($4);
            $$ -> add($5);

			logFile<<$$->name<<endl;
		   
	  }
	  | IF LPAREN expression RPAREN statement ELSE statement
	  {
			$$ = new Helper("statement : IF LPAREN expression RPAREN statement ELSE statement ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $7->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
            $$ -> add($3);
            $$ -> add($4);
            $$ -> add($5);
            $$ -> add($6);
            $$ -> add($7);
       

			logFile<<$$->name<<endl;
	  }
	  | WHILE LPAREN expression RPAREN statement
	  {
			$$ = new Helper("statement : WHILE LPAREN expression RPAREN statement ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $5->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
            $$ -> add($3);
            $$ -> add($4);
            $$ -> add($5);

			logFile<<$$->name<<endl;
		
	  }
	  | PRINTLN LPAREN ID RPAREN SEMICOLON 
	  {
		 	$$ = new Helper("statement : PRINTLN LPAREN ID RPAREN SEMICOLON ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $5->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
            $$ -> add($3.helper);
            $$ -> add($4);
            $$ -> add($5);
     

			logFile<<$$->name<<endl;
	  }
	  | RETURN expression SEMICOLON
	  {
			$$ = new Helper("statement : RETURN expression SEMICOLON ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $3->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
            $$ -> add($3);
           

			$$ -> returnType = $2 -> type;

			logFile<<$$->name<<endl;
	  }
	  ;
	  
expression_statement : SEMICOLON
			{
				$$ = new Helper("expression_statement : SEMICOLON ");

				$$ -> start_line = $1->start_line;
				$$ -> end_line = $1->end_line;
				
				$$ -> add($1);
                

				logFile<<$$->name<<endl;
				
			}		
			| expression SEMICOLON 
			{
				$$ = new Helper("expression_statement : expression SEMICOLON ");

				$$ -> start_line = $1->start_line;
				$$ -> end_line = $2->end_line;
				
				$$ -> add($1);
                $$ -> add($2);
             

				logFile<<$$->name<<endl;
				
			}
			;
	  
variable : ID 
	 {
		$$ = new Helper("variable : ID ");

		$$ -> start_line = $1.helper->start_line;
		$$ -> end_line = $1.helper->end_line;
		
		$$ -> add($1.helper);

		SymbolInfo* lookupSymbol = symboltable->lookup($1.symbol->getName());

		if(lookupSymbol == nullptr)
		{
			
			errorFile<<"Line# "<<$1.helper->start_line<<": Undeclared variable '"<<$1.symbol->getName()<<"'"<<endl;
			error_count++;
		}
		else
		{
			
			$$ -> type = lookupSymbol->getType();
			
		}

		logFile<<$$->name<<endl;
		
	 }		
	 | ID LSQUARE expression RSQUARE 
	 {
		$$ = new Helper("variable : ID LSQUARE expression RSQUARE ");

		$$ -> start_line = $1.helper->start_line;
		$$ -> end_line = $4->end_line;
		
        $$ -> add($1.helper);
        $$ -> add($2);
        $$ -> add($3);
        $$ -> add($4);


		SymbolInfo* lookupSymbol = symboltable->lookup($1.symbol->getName());

		if(lookupSymbol == nullptr)
		{
			
			errorFile<<"Line# "<<$1.helper->start_line<<": Undeclared array '"<<$1.symbol->getName()<<"'"<<endl;
			error_count++;
		}
		else if(lookupSymbol -> getType() != "ARRAY")
		{
			errorFile<<"Line# "<<$1.helper->start_line<<": '"<<lookupSymbol->getName()<<"' is not an array"<<endl;
			error_count++;
		}
		else 
		{
			
			if($3 -> type != "INT" && $3 -> type != "")
			{
				errorFile<<"Line# "<<$3->start_line<<": Array subscript is not an integer"<<endl;
				error_count++;
			}
			else
				$$ -> type = lookupSymbol->additionalType;

			
		}

		logFile<<$$->name<<endl;
	 }
	 ;
	 
 expression : logic_expression	
		{
			$$ = new Helper("expression : logic_expression ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
           


			$$ -> type = $1 -> type;

			logFile<<$$->name<<endl;
			
		}
	   | variable ASSIGNOP logic_expression
	   {
			$$ = new Helper("expression : variable ASSIGNOP logic_expression ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
            $$ -> add($3);


			if($3 -> type == "VOID")
			{
				errorFile<<"Line# "<<$3->start_line<<": Void cannot be used in expression "<<endl;
				error_count++;
			}

			else if($1 -> type == "INT" && $3 -> type == "FLOAT")
			{
				errorFile<<"Line# "<<$2->start_line<<": Warning: possible loss of data in assignment of FLOAT to INT"<<endl;
				error_count++;
			}

			else if($1 -> type == "ARRAY" || $3->type == "ARRAY")
			{
				errorFile<<"Line# "<<$2->start_line<<": invalid array assignment "<<endl;
				error_count++;
			}
		
			
			logFile<<$$->name<<endl;
	   } 	
	   ;
			
logic_expression : rel_expression
		 {
			$$ = new Helper("logic_expression : rel_expression ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
            


			$$ -> type = $1 -> type;

			logFile<<$$->name<<endl;
		 }
		 | rel_expression LOGICOP rel_expression 
		 {
			$$ = new Helper("logic_expression : rel_expression LOGICOP rel_expression ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $3->end_line;
			
			$$ -> add($1);
            $$ -> add($2.helper);
            $$ -> add($3);

			

			if($1 -> type != "VOID" && $3->type != "VOID")
			{
				$$ -> type = "INT"; 
			}
			else
			{
				errorFile<<"Line# "<<$2.helper->start_line<<": Logic op can't be used with Void type "<<endl;
				error_count++;
			}
				
			
			logFile<<$$->name<<endl;
		 }	
		 ;
			
rel_expression : simple_expression
		{
			$$ = new Helper("rel_expression : simple_expression ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
           

			$$ -> type = $1->type;

			logFile<<$$->name<<endl;
		
		}
		| simple_expression RELOP simple_expression	
		{
			$$ = new Helper("rel_expression : simple_expression RELOP simple_expression ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $3->end_line;
			
			$$ -> add($1);
            $$ -> add($2.helper);
            $$ -> add($3);


			if($1 -> type == "VOID" || $3 -> type == "VOID")
			{
				errorFile<<"Line# "<<$2.helper->start_line<<": Operand is void"<<endl;
				error_count++;
			}
			else if($1 -> type == "INT" && $3 -> type != "ARRAY")
			{

				$$ -> type = "INT";
			}

			else if($1 -> type == "FLOAT" && $3->type != "ARRAY")
			{

				$$ -> type = "INT";
			}
			else if($1 -> type == "ARRAY" && $3->type == "ARRAY")
			{
				$$ -> type = "INT";
				
			}
			else if($1 -> type == "ARRAY" && $3 -> type != "ARRAY")
			{
				
				errorFile<<"Line# "<<$3->start_line<<": both operand is not an array"<<endl;
				error_count++;
			}
			else if($3 -> type == "ARRAY" && $1 -> type != "ARRAY")
			{
				errorFile<<"Line# "<<$3->start_line<<": both operand is not an array"<<endl;
				error_count++;
				
			}

			logFile<<$$->name<<endl;
		}
		;
				
simple_expression : term 
		  {
			 $$ = new Helper("simple_expression : term ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			 $$ -> add($1);
            
			 $$ -> type = $1 -> type;

			 logFile<<$$->name<<endl;

		  }
		  | simple_expression ADDOP term
		  {
			 $$ = new Helper("simple_expression : simple_expression ADDOP term ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $3->end_line;
			
			$$ -> add($1);
            $$ -> add($2.helper);
            $$ -> add($3);
          


			 if($1 -> type == "ARRAY")
			 {
				 errorFile<<"Line# "<<$1->start_line<<"can't add an array"<<endl;
				 error_count++;
			 }
			 else if($3 -> type == "ARRAY")
			 {
				 errorFile<<"Line# "<<$3->start_line<<"can't add an array"<<endl;
				 error_count++;
			 }
			 else if($1 -> type == "VOID" || $3 -> type == "VOID")
			 {
				 errorFile<<"Line# "<<$2.helper->start_line<<"operands are void type"<<endl;
				 error_count++;
			 }
			 else if($1 -> type == "FLOAT" || $3 -> type == "FLOAT")
			 {
					$$ -> type = "FLOAT";
			 }
			 else if($1 -> type == "INT" && $3 -> type == "INT")
			 {
					$$ -> type = "INT";
			 }

			 logFile<<$$->name<<endl;
		  } 
		  ;
					
term : unary_expression
	 {
		$$ = new Helper("term : unary_expression ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $1->end_line;
		
		$$ -> add($1);
    

		$$ -> type = $1 -> type;

		logFile<<$$->name<<endl;
		
	 }
     |  term MULOP unary_expression
	 {
		$$ = new Helper("term : term MULOP unary_expression ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $3->end_line;
		
		$$ -> add($1);
        $$ -> add($2.helper);
        $$ -> add($3);
       

		if($2.symbol->getName() == "%" || $2.symbol->getName() == "/")
		{
			if($3 -> value == "0" || $3 -> value == "0.0")
			{
				errorFile<<"Line# "<<$3->start_line<<": Warning: division by zero i=0f=1Const=0"<<endl;
				error_count++;
			}

			else if($2.symbol -> getName() == "%")
			{
				if($1 -> type != "INT" || $3 -> type != "INT")
				{
					errorFile<<"Line# "<<$2.helper->start_line<<": Operands of modulus must be integers "<<endl;

					error_count++;
				}
				else
				{
					$$ -> type = "INT";
				}
			}
			else if ($2.symbol -> getName() == "/")
			{
				if($1 -> type == "VOID" || $3 -> type == "VOID")
				{
					
					errorFile<<"Line# "<<$2.helper ->start_line<<": Void cannot be used in expression "<<endl;
					error_count++;
				}
				else if($1 -> type == "ARRAY" || $3 -> type == "ARRAY")
				{
					
					errorFile<<"Line# "<<$2.helper->start_line<<": operand is an array "<<endl;
					error_count++;
		
				}
				else if($1 -> type == "FLOAT" || $3 -> type == "FLOAT")
				{
					$$ -> type = "FLOAT";
				}
				else if( $1 -> type == "INT" && $3 -> type == "INT")
				{
					$$ -> type = "INT";
				}
			}
		}
		else
		{
			
			if($1 -> type == "VOID" || $3 -> type == "VOID")
			{
				
				errorFile<<"Line# "<<$2.helper ->start_line<<": Void cannot be used in expression "<<endl;
				error_count++;
			}
			else if($1 -> type == "ARRAY" || $3 -> type == "ARRAY")
			{
				
				errorFile<<"Line# "<<$2.helper ->start_line<<": invalid array operation "<<endl;
				error_count++;
			}
			else if($1 -> type == "FLOAT" || $3 -> type == "FLOAT")
			{
				$$ -> type = "FLOAT";
			}
			else if($1 -> type == "INT" && $3 -> type == "INT")
			{
				$$ -> type = "INT";
			}
		}

		logFile<<$$->name<<endl;
	 }
     ;

unary_expression : ADDOP unary_expression
		{
			$$ = new Helper("unary_expression : ADDOP unary_expression ");

			$$ -> start_line = $1.helper->start_line;
			$$ -> end_line = $2->end_line;
			
			$$ -> add($1.helper);
            $$ -> add($2);
   


			if($2 -> type == "VOID")
			{
				errorFile<<"Line# "<<$2->start_line<<": Operand is void"<<endl;
			}
			else if($2 -> type == "ARRAY")
			{
				errorFile<<"Line# "<<$2->start_line<<": Operand is array"<<endl;
			}
			else
			{
				$$ -> type = $2 -> type;
			}
			
			logFile<<$$->name<<endl;
		}
		 | NOT unary_expression 
		 {
			$$ = new Helper("unary_expression : NOT unary_expression ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $2->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
           


			if($2 -> type == "VOID")
			{
				errorFile<<"Line# "<<$2->start_line<<": Operand is void"<<endl;
			}
			else if($2 -> type == "ARRAY")
			{
				errorFile<<"Line# "<<$2->start_line<<": Operand is array"<<endl;
			}
			else
			{
				$$ -> type = "INT";
			}

			logFile<<$$->name<<endl;
		 }
		 | factor
		 {
			$$ = new Helper("unary_expression : factor ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
        


			$$ -> type = $1 -> type;

			$$ -> value = $1 -> value; // for checking 0

			logFile<<$$->name<<endl;
		
		 } 
		 ;
	
factor	: variable 
	{
		$$ = new Helper("factor : variable ");
		
		$$ -> start_line = $1->start_line;
		$$ -> end_line = $1->end_line;
		
		$$ -> add($1);

		$$ -> type = $1 -> type;

		logFile<<$$->name<<endl;
		
	}
	| ID LPAREN argument_list RPAREN 
	{
		$$ = new Helper("factor : ID LPAREN argument_list RPAREN ");
		

		$$ -> start_line = $1.helper->start_line;
		$$ -> end_line = $4->end_line;
		
		$$ -> add($1.helper);
        $$ -> add($2);
        $$ -> add($3);
        $$ -> add($4);

		


		SymbolInfo* lookupSymbol = symboltable->lookup($1.symbol -> getName());

		if(lookupSymbol == nullptr)
		{
			errorFile<<"Line# "<<$1.helper->start_line<<": Undeclared function '"<<$1.symbol->getName()<<"'"<<endl;
			error_count++;
		}
		else if(lookupSymbol -> getType()  != "FUNCTION")
		{
			errorFile<<"Line# "<<$1.helper->start_line<<": '"<<$1.symbol->getName()<<"' is not a function"<<endl;
			error_count++;
		}
		else if(lookupSymbol -> getType() == "FUNCTION" && lookupSymbol -> isdefined == false)
		{
			errorFile<<"Line# "<<$1.helper->start_line<<": func '"<<$1.symbol->getName()<<"' is declared but not defined"<<endl;
			error_count++;
		}
		else
		{
			bool ok = true;

			for(int i=0;i<temp_arguments.size();i++)
			{
				if(temp_arguments[i] == "ERROR")
				{
					ok = false;
					break;
				}
			}

			if(ok)
			{
				if(temp_arguments.size() > lookupSymbol -> param_type.size())
				{
					errorFile<<"Line# "<<$3->start_line<<": Too many arguments to function '"<<lookupSymbol->getName()<<"'"<<endl;
					error_count++;
				}
				else if(temp_arguments.size() < lookupSymbol -> param_type.size())
				{
					errorFile<<"Line# "<<$3->start_line<<": Too few arguments to function '"<<lookupSymbol->getName()<<"'"<<endl;
					error_count++;
				}
				else
				{
					

					for(int i=0;i<temp_arguments.size();i++)
					{
						if(temp_arguments[i] != lookupSymbol->param_type[i])
						{
							errorFile<<"Line# "<<$3->start_line<<": Type mismatch for argument "<<i+1<<" of '"<<lookupSymbol->getName()<<"'"<<endl;
							error_count++;
						}
					}

					
					$$ -> type = lookupSymbol->additionalType;
					

				}
			}
			else
			{
				$$ -> type = lookupSymbol->additionalType;
			}
		}

		
		
		temp_arguments.clear();

		logFile<<$$->name<<endl;

	}
	| LPAREN expression RPAREN
	{
		$$ = new Helper("factor : LPAREN expression RPAREN ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $3->end_line;
		
		$$ -> add($1);
        $$ -> add($2);
        $$ -> add($3);

		$$ -> type = $2 -> type;

		logFile<<$$->name<<endl;

	}
	| CONST_INT 
	{
		$$ = new Helper("factor : CONST_INT ");
	
		$$ -> start_line = $1.helper->start_line;
		$$ -> end_line = $1.helper->end_line;
		
		$$ -> add($1.helper);
      

		

		$$ -> type = "INT";

		$$ -> value = $1.symbol->getName();

		logFile<<$$->name<<endl;
		
	}
	| CONST_FLOAT
	{
		$$ = new Helper("factor : CONST_FLOAT ");

		$$ -> start_line = $1.helper->start_line;
		$$ -> end_line = $1.helper->end_line;
		
		$$ -> add($1.helper);
       

		$$ -> type = "FLOAT";

		$$ -> value = $1.symbol->getName();

		logFile<<$$->name<<endl;


	}
	| variable INCOP 
	{
		$$ = new Helper("factor : variable INCOP ");
		

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $1->end_line;
		
		$$ -> add($1);
        $$ -> add($2);

		if($1 -> type == "ARRAY")
		{
			errorFile<<"Line# "<<$1->start_line<<": invalid array operation "<<endl;
			error_count++;
		}
		else
			$$ -> type = $1 -> type;

		logFile<<$$->name<<endl;
		
		
	}
	| variable DECOP 
	{
		$$ = new Helper("factor : variable DECOP ");
		

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $2->end_line;
		
		$$ -> add($1);
        $$ -> add($2);
     
		if($1 -> type == "ARRAY")
		{
			errorFile<<"Line# "<<$1->start_line<<": invalid array operation "<<endl;
			error_count++;
		}
		else
			$$ -> type = $1 -> type;

		logFile<<$$->name<<endl;

	}
	;
	
argument_list : arguments
				{
					$$ = new Helper("argument_list : arguments ");

					$$ -> start_line = $1->start_line;
					$$ -> end_line = $1->end_line;
					
					$$ -> add($1);
               
					
					$$ -> parse_tree += "\n";
					$$ -> parse_tree += $1->parse_tree;

					logFile<<$$->name<<endl;

					
				}
			  | 
			  {
					$$ = new Helper("argument_list : ");

					$$ -> start_line = line_count;   //notice
					$$ -> end_line = line_count;
					
					

					logFile<<$$->name<<endl;


			  }
			  ;
	
arguments : arguments COMMA logic_expression
		   {
				$$ = new Helper("arguments : arguments COMMA logic_expression ");

				$$ -> start_line = $1->start_line;
				$$ -> end_line = $3->end_line;
				
				$$ -> add($1);
                $$ -> add($2);
                $$ -> add($3);

				if($3->type == "")
				{
					temp_arguments.push_back("ERROR");
				}
				else
					temp_arguments.push_back($3 -> type);

				logFile<<$$->name<<endl;
				
			

		   }
	      | logic_expression
		  {
			 	$$ = new Helper("arguments : logic_expression ");

				$$ -> start_line = $1->start_line;
				$$ -> end_line = $1->end_line;
				
				$$ -> add($1);


				if($1->type == "")
				{
					temp_arguments.push_back("ERROR");
				}
				else
					temp_arguments.push_back($1 -> type);

				logFile<<$$->name<<endl;
				
		  }
	      ;


%%
int main(int argc,char *argv[])
{
	

	if((fp=fopen(argv[1],"r"))==NULL)
	{
		printf("Cannot Open Input File.\n");
		exit(1);
	}

	parseFile.open("1905098_parsetree.txt");
	errorFile.open("1905098_error.txt"); 
	logFile.open("1905098_log.txt");

	symboltable = new SymbolTable(11, &logFile);
	symboltable->Enter_Scope(); 
	
	yyin = fp;

	
	yyparse();
	
	
	//symboltable -> Print_All_Scope_Table();

	logFile<<"Total Lines: "<<line_count<<endl;
	logFile<<"Total Errors: "<<error_count<<endl;
	fclose(fp);

	delete symboltable;
	
	return 0;
}

