#include<iostream>
#include<cstdlib>
#include<fstream>
#include<string>

using namespace std;

class SymbolInfo
{
    string name,type;

public:

    SymbolInfo* next;

    int pos,index,scopeNumber;

    ~SymbolInfo()
    {

    }

    void setName(string name)
    {
        this->name = name;
    }
    string getName()
    {
        return this->name;
    }
    void setType(string type)
    {
        this->type = type;
    }
    string getType()
    {
        return this->type;
    }

};

class ScopeTable
{

    ofstream* out;

    SymbolInfo** bucket;

    int total_buckets;



    unsigned long long int sdbm_hash(string name)
    {
        unsigned long long int hashval = 0;
        unsigned int i = 0;
        unsigned int len = name.length();

        for (i = 0; i < len; i++)
        {
            hashval = ((name[i]) + (hashval << 6) + (hashval << 16) - hashval);
        }

        return hashval;

    }

public:

    int scopeNumber;

    ScopeTable* parent_scope;

    ScopeTable(int n,int scopeNumber,ofstream* out)
    {
        this->total_buckets = n;

        this->scopeNumber = scopeNumber;

        bucket = new SymbolInfo*[n];

        for(int i=0;i<n;i++)
        {
            bucket[i] = nullptr;
        }
        this->out = out;
    }
    ~ScopeTable()
    {

        //*out<<"\tScopeTable# "<<scopeNumber<<" removed"<<endl;

        for(int i=0;i<total_buckets;i++)
        {
            SymbolInfo* curr = bucket[i];

            SymbolInfo* temp;

            while(curr != nullptr)
            {
                temp = curr;

                curr = curr->next;

                delete temp;

            }
        }

        delete bucket;

    }

    SymbolInfo* lookup(string symbolName)
    {

        int index = sdbm_hash(symbolName) % total_buckets;

        SymbolInfo* curr = bucket[index];

        int pos = 0;

        while(curr != nullptr)
        {
            if(curr->getName() == symbolName)
            {
                curr->pos = pos;
                curr->index = index;
                curr->scopeNumber = this->scopeNumber;

                return curr;
            }

            curr = curr->next;

            pos++;
        }

        return nullptr;
    }

    bool Insert(SymbolInfo* symbolObj)
    {

        if(lookup(symbolObj->getName()) == nullptr)
        {

            int index =  sdbm_hash(symbolObj->getName()) % total_buckets;

            int pos = 0;

            SymbolInfo* curr = bucket[index];

            if(curr == nullptr)
            {

                bucket[index] = symbolObj;
                bucket[index] -> next = nullptr;
            }
            else
            {
                while(curr->next != nullptr)
                {
                    curr = curr -> next;
                    pos++;
                }
                pos++;
                curr->next = symbolObj;
                curr -> next -> next = nullptr;
            }

            //*out<<"\tInserted in ScopeTable# "<<this->scopeNumber<<" at position "<<index+1<<","<<" "<<pos + 1<<endl;

            return true;
        }
        else
        {
            *out<<"\t"<<""<<symbolObj->getName()<<" "<<"already exists in the current ScopeTable"<<endl;

            return false;
        }
    }
    bool Delete(string symbolName)
    {
        if(lookup(symbolName) == nullptr)
        {
            *out<<"\tNot found in the current ScopeTable"<<endl;

            return false;
        }
        else
        {
            int index = sdbm_hash(symbolName) % total_buckets;

            SymbolInfo* curr = bucket[index];

            int pos = 0;

            if(curr->getName() == symbolName)
            {
                bucket[index] = bucket[index] -> next;

            }
            else
            {
                SymbolInfo* temp;

                while(curr->next != nullptr)
                {
                    if(curr->next->getName() == symbolName)
                    {
                        pos++;

                        temp = curr->next;

                        curr -> next = curr -> next -> next;

                        break;
                    }

                    curr = curr -> next;

                    pos++;
                }

                delete temp;
            }

            *out<<"\tDeleted '"<<symbolName<<"' "<<"from ScopeTable# "<<this->scopeNumber<<" at position "<<index+1<<","<<" "<<pos + 1<<endl;

            return true;
        }
    }
    void Print()
    {
        *out<<"\tScopeTable# "<<scopeNumber<<endl;

        for(int index=1;index<=total_buckets;index++)
        {
            
            SymbolInfo* curr = bucket[index - 1];
	    
	    if(curr == nullptr) continue;
	    
            *out<<"\t"<<index<<"--> ";

            while(curr != nullptr)
            {
                *out<<"<"<<curr->getName()<<","<<curr->getType()<<"> ";

                curr = curr -> next;
            }
            *out<<endl;
        }
    }
};

class SymbolTable
{
    ofstream* out;
    int scopeNumber;
    int bucketSize;

public:

    ScopeTable* currScope;

    SymbolTable(int n,ofstream* out)
    {
        scopeNumber = 1;

        bucketSize = n;

        currScope = nullptr;

        this->out = out;
        
    }
    ~SymbolTable()
    {
        ScopeTable* temp;

        while(currScope != nullptr)
        {
            temp = currScope;

            currScope = currScope ->parent_scope;

            delete temp;
        }
    }
    void Enter_Scope()
    {
        ScopeTable* new_scope_table = new ScopeTable(bucketSize,scopeNumber,out);

        ScopeTable* parent_scope_table = currScope;

        currScope = new_scope_table;

        currScope -> parent_scope = parent_scope_table;

        //*out<<"\tScopeTable# "<<scopeNumber<<" created"<<endl;

        ++scopeNumber;

    }
    void Exit_Scope()
    {
        if(currScope->parent_scope != nullptr)
        {
            ScopeTable* temp = currScope;
            currScope = currScope->parent_scope;
            delete temp;
        }
        else
        {
            //*out<<"\tScopeTable# "<<currScope->scopeNumber<<" cannot be removed"<<endl;
        }
    }
    bool Insert(SymbolInfo* symbol)
    {
        if(currScope == nullptr)
        {
                ScopeTable* new_scope_table = new ScopeTable(bucketSize,scopeNumber,out);

		ScopeTable* parent_scope_table = currScope;

		currScope = new_scope_table;

		currScope -> parent_scope = parent_scope_table;

		//*out<<"\tScopeTable# "<<scopeNumber<<" created"<<endl;

		++scopeNumber;
        }

        return (currScope->Insert(symbol));
    }

    bool Remove(string symbolName)
    {
        if(currScope == nullptr)
        {
            return false;
        }
        else
        {

            return currScope->Delete(symbolName);
        }
    }
    SymbolInfo* lookup(string symbolName)
    {

        ScopeTable* temp = currScope;

        while(temp != nullptr)
        {
            SymbolInfo* symbol = temp->lookup(symbolName);

            if(symbol == nullptr)
            {
                temp = temp -> parent_scope;
            }
            else
            {
                *out<<"\t'"<<symbolName<<"'"<<" found in ScopeTable# "<<symbol->scopeNumber<<" at position "<<symbol->index + 1<<", "<<symbol->pos + 1<<endl;
                return symbol;
            }
        }

        *out<<"\t'"<<symbolName<<"'"<<" not found in any of the ScopeTables"<<endl;

        return nullptr;


    }
    void Print_Current_Scope_Table()
    {
        currScope->Print();
    }
    void Print_All_Scope_Table()
    {
        ScopeTable* temp = currScope;
	
        while(temp != nullptr)
        {
            temp->Print();
            temp = temp->parent_scope;
        }
    }
};



