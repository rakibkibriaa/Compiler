%{
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<bits/stdc++.h>
#include "1905098_Helper.h"

using namespace std;

int yyparse(void);
int yylex(void);

extern FILE *yyin; 

extern int line_count;

ofstream parseFile;
ofstream errorFile;
ofstream logFile;

ofstream tempFile;
ofstream asmFile;
ofstream optimizedCodeFile;

SymbolTable *symboltable;
FILE* fp;


bool isMain = false;

int var_count = 0;

map<string,string> mp;

int error_count = 0;

stack<string> stack_;

stack<int> varStack;

int param_size;


struct combined {

	Helper* helper;
	SymbolInfo* symbol;

} temp_value;


vector<combined> temp_parameter;

vector<combined> temp_variable;

vector<string> temp_arguments;

vector<string> func_params;

void yyerror(char *s)
{
	

}

void print_parse_tree(Helper* helper,int depth)
{
   
    for(int i=0;i<depth;i++)
    {
        parseFile<<" ";
    }

    parseFile<<helper->name;
    parseFile<<"\t";

    if(helper->isLeaf == false)
    {
        parseFile<<"<Line: ";
        parseFile<<helper->start_line;
        parseFile<<"-";
        parseFile<<helper->end_line;
        parseFile<<">";
    }
    else
    {
        parseFile<<"<Line: ";
        parseFile<<helper->start_line;
        parseFile<<">";

    }
    
    parseFile<<endl;

    if(helper->isLeaf)
    {
        return;
    }

    for(int i=0;i<helper->childVector.size();i++)
    {
        print_parse_tree(helper->childVector[i],depth + 1);
    }
    
}
void delete_tree(Helper* helper)
{
	
   for(int i=0;i<helper->childVector.size();i++)
   {
	  delete_tree(helper->childVector[i]);
   }
   helper->childVector.clear();

   delete helper;

}

int labelCount=0;
int tempCount=0;


char *newLabel()
{
	char *lb= new char[4];
	strcpy(lb,"L");
	char b[3];
	sprintf(b,"%d",labelCount);
	labelCount++;
	strcat(lb,b);
	return lb;
}

char *newTemp()
{
	char *t= new char[4];
	strcpy(t,"t");
	char b[3];
	sprintf(b,"%d",tempCount);
	tempCount++;
	strcat(t,b);
	return t;
}

void buildFinalCode()
{
	ifstream tempFileIn("1905098_temp.txt"); //hardocded
	asmFile.open("code.asm");
	asmFile<<".MODEL SMALL"<<endl;
	asmFile<<".STACK 1000H"<<endl;
	asmFile<<".DATA"<<endl;
	asmFile<<"number DB "<<"\"00000$\""<<endl;
	string line;
	while(getline(tempFileIn,line))
	{
		//cout<<line<<endl;
		
		if(line[0] == '#')
		{
			asmFile<<line.substr(1)<<endl;
		}
	}
	
	ifstream tempFile2("1905098_temp.txt");
	asmFile<<".CODE"<<endl;
	while(getline(tempFile2,line))
	{

	
		if(line[0] != '#')
		{
			asmFile<<line<<endl;
		}
		
	}

	char* func = "println proc\r\n"
			"push ax\r\n"
			"push bx\r\n"
			"push cx\r\n"
			"push dx\r\n"
			"push si\r\n"
			"lea si,number\r\n"
			"mov bx,10\r\n"
			"add si,4\r\n"
			"cmp ax,0\r\n"
			"jnge negate\r\n"
		"print:\r\n"
			"xor dx,dx\r\n"
			"div bx\r\n"
			"mov [si],dl\r\n"
			"add [si],'0'\r\n"
			"dec si\r\n"
			"cmp ax,0\r\n"
			"jne print\r\n"
			"inc si\r\n"
			"lea dx,si\r\n"
			"mov ah,9\r\n"
			"int 21h\r\n"
			"mov ah,2\r\n"
			"mov dl,0DH\r\n"
			"int 21h\r\n"
			"mov ah,2\r\n"
			"mov dl,0AH\r\n"
			"int 21h\r\n"
			"pop si\r\n"
			"pop dx\r\n"
			"pop cx\r\n"
			"pop bx\r\n"
			"pop ax\r\n"
			"ret\r\n"
		"negate:\r\n"
			"push ax\r\n"
			"mov ah,2\r\n"
			"mov dl,'-'\r\n"
			"int 21h\r\n"
			"pop ax\r\n"
			"neg ax\r\n"
			"jmp print\r\n"
		"println endp\r\n";

		asmFile<<func<<endl;
		asmFile<<"END MAIN"<<endl;
	

}

void optimizeCode()
{
	ifstream tempIn("code.asm");

	optimizedCodeFile.open("optimized_code.asm");

	string line;

	vector<string> linearray;

	while(getline(tempIn,line))
	{
		linearray.push_back(line);
	}

	for(int i=0;i<linearray.size();i++)
	{
		string temp_line1 = linearray[i];
		string temp_line2;

		if(i + 1 < linearray.size())
			temp_line2 = linearray[i+1];
		else 
		{
			optimizedCodeFile<<temp_line1<<endl;
			continue;
		}

		if(temp_line1.size()>=4 && temp_line2.size()>=4 && temp_line1.substr(1,3) == "MOV" && temp_line2.substr(1,3) == "MOV")
		{
			string cut_1 = temp_line1.substr(5);
			string cut_2 = temp_line2.substr(5);


			int index_comma1= cut_1.find(',');
			int index_comma2= cut_2.find(',');

			if(cut_1.substr(0,index_comma1) == cut_2.substr(index_comma2 + 1))
			{
				if(cut_1.substr(index_comma1+1) == cut_2.substr(0,index_comma2))
				{
					i++;
					continue;
				}
			}
		}

		if(temp_line1.size()>=7 && temp_line2.size()>=6 && temp_line1.substr(1,4) == "PUSH" && temp_line2.substr(1,3) == "POP")
		{
			string cut_1 = temp_line1.substr(6);
			string cut_2 = temp_line2.substr(5);

			if(cut_1 == cut_2)
			{
				
				i++;
				
				continue;
				
			}

		}

		
		optimizedCodeFile<<temp_line1<<endl;


	}

}


%}


%union 
{
	

	struct
	{
		SymbolInfo* symbol;
		Helper* helper;

	} value;
	

}




%token <value> CONST_INT CONST_FLOAT ID LOGICOP RELOP ADDOP MULOP
%token <value.helper> INT DO CHAR DOUBLE CONTINUE
%token <value.helper> FLOAT VOID IF ELSE FOR WHILE PRINTLN RETURN LOWER_THAN_ELSE
%token <value.helper> ASSIGNOP NOT INCOP DECOP
%token <value.helper> LPAREN RPAREN LCURL RCURL LSQUARE RSQUARE COMMA SEMICOLON 


%type <value.helper> start program unit var_declaration func_declaration func_definition declaration_list type_specifier parameter_list compound_statement
%type <value.helper> statements statement expression_statement expression variable logic_expression rel_expression simple_expression term IF_END
%type <value.helper> unary_expression factor argument_list arguments IF_COMMON 


%nonassoc LOWER_THAN_ELSE
%nonassoc ELSE

%%

start : program
	{

		buildFinalCode();
		optimizeCode();

		$$ = new Helper("start : program ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $1->end_line;


        $$ -> add($1);
   

        print_parse_tree($$,0);


		logFile<<$$->name<<endl;

		delete_tree($$);
		
	}
	;

program : program unit 
	{
		$$ = new Helper("program : program unit ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $2->end_line;
		
		$$ -> add($1);
        $$ -> add($2);
      
		
		logFile<<$$->name<<endl;
	}
	| unit
	{
		$$ = new Helper("program : unit ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $1->end_line;
		
		$$ -> add($1);
 
		
		logFile<<$$->name<<endl;

	}
	;
	
unit : var_declaration 
	 {
		$$ = new Helper("unit : var_declaration ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $1->end_line;
		
		$$ -> add($1);


		logFile<<$$->name<<endl;
	
	 }
     | func_declaration
	 {
		$$ = new Helper("unit : func_declaration ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $1->end_line;
		
		$$ -> add($1);


		logFile<<$$->name<<endl;
	 }
     | func_definition
	 {
		$$ = new Helper("unit : func_definition ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $1->end_line;

		$$ -> add($1);
   

		logFile<<$$->name<<endl;
	 }
     ;
     
func_declaration : type_specifier ID LPAREN parameter_list RPAREN SEMICOLON 
		{
			$$ = new Helper("func_declaration : type_specifier ID LPAREN parameter_list RPAREN SEMICOLON ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $6->end_line;
			
			$$ -> add($1);
            $$ -> add($2.helper);
            $$ -> add($3);
            $$ -> add($4);
            $$ -> add($5);
            $$ -> add($6);
          
            
			SymbolInfo* symbol = new SymbolInfo($2.symbol->getName(),"FUNCTION");

			for(int i=0;i<temp_parameter.size();i++)
			{
				symbol->param_type.push_back(temp_parameter[i].symbol->getType());
			}

			symbol->additionalType = $1->type;
			symbol->isdefined = false;

			if(symboltable->Insert(symbol))
			{
					//successfully inserted
			}
			else
			{
				
				//2 cases; symbol table has symbol which is fuction type or not 

				SymbolInfo* lookupSymbol = symboltable->lookup(symbol->getName());

				if(lookupSymbol->getType() == "FUNCTION")
				{
					errorFile<<"Line# "<<$2.helper->start_line<<": '"<<lookupSymbol->getName()<<"' function has multiple declaration"<<endl;
					error_count++;
				}
				else
				{
					errorFile<<"Line# "<<$2.helper->start_line<<": '"<<lookupSymbol->getName()<<"' redeclared as different kind of symbol"<<endl;
					error_count++;
				}

				delete symbol;


			}

			temp_parameter.clear();

			logFile<<$$->name<<endl;

		}
		| type_specifier ID LPAREN RPAREN SEMICOLON 
		{
			$$ = new Helper("func_declaration : type_specifier ID LPAREN RPAREN SEMICOLON ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $5->end_line;
			
			$$ -> add($1);
            $$ -> add($2.helper);
            $$ -> add($3);
            $$ -> add($4);
            $$ -> add($5);



			SymbolInfo* symbol = new SymbolInfo($2.symbol->getName(),"FUNCTION");


			symbol->additionalType = $1->type;
			symbol->isdefined = false;

			if(symboltable->Insert(symbol))
			{
				//successfully inserted
			}
			else
			{
				//2 cases; symbol table has symbol which is fuction type or not 

				SymbolInfo* lookupSymbol = symboltable->lookup(symbol->getName());

				if(lookupSymbol->getType() == "FUNCTION")
				{
					errorFile<<"Line# "<<$2.helper->start_line<<": '"<<lookupSymbol->getName()<<"' function has multiple declaration"<<endl;
					
					
				}
				else
				{
					errorFile<<"Line# "<<$2.helper->start_line<<": '"<<lookupSymbol->getName()<<"' redeclared as different kind of symbol"<<endl;
					
				}
				error_count++;

				delete symbol;


			}

			
			logFile<<$$->name<<endl;
		}
		;
		 
func_definition : type_specifier ID LPAREN parameter_list RPAREN
{

	SymbolInfo* symbol = new SymbolInfo($2.symbol->getName(),"FUNCTION");

	int size = temp_parameter.size();

	for(int i=0;i<temp_parameter.size();i++)
	{
		symbol->param_type.push_back(temp_parameter[i].symbol->getType());

		
	}

	symbol->additionalType = $1->type;
	symbol->isdefined = true;



	var_count = 0;

	tempFile << $2.symbol->getName() << " PROC" <<endl;


    if ($2.symbol->getName()  == "main")
    {
		isMain = true;
        
        tempFile <<"\tMOV AX,@DATA"<<endl;
		tempFile<<"\tMOV DS,AX"<<endl;
		tempFile<<"\tPUSH BP"<<endl;
        
    }
	else
	{
        isMain = false;

        tempFile<<"\tPUSH BP"<<endl; 
    }


    tempFile<<"\tMOV BP,SP"<<endl;

	if(symboltable->Insert(symbol))
	{
		//successfully inserted
	}
	else
	{
		//already exists in symbol table

		SymbolInfo* lookupSymbol = symboltable->lookup(symbol->getName());

		if(lookupSymbol->getType() == "FUNCTION")
		{
			if(lookupSymbol->isdefined == false) //declared but not defined
			{

				bool ok = true;

				
				if(temp_parameter.size() != lookupSymbol->param_type.size()) //parameter size
				{
					errorFile<<"Line# "<<$1->start_line<<": Conflicting types for '"<<lookupSymbol->getName()<<"'"<<endl;
					ok = false;
					error_count++;
				}

				if(lookupSymbol->additionalType != $1->type) // return type
				{
					ok = false;

					errorFile<<"Line# "<<$1->start_line<<": Conflicting types for '"<<lookupSymbol->getName()<<"'"<<endl;

					error_count++;
				}

				if(ok) // total parameters and return type is ok then check parameter types
				{
					for(int i=0;i<lookupSymbol->param_type.size();i++) // check parameter type
					{            
						if(temp_parameter[i].symbol->getType() != lookupSymbol->param_type[i])
						{
							errorFile<<"Line# "<<$1->start_line<<": Conflicting types for '"<<lookupSymbol->getName()<<"' parameter "<<temp_parameter[i].symbol->getName()<<endl;
							ok = false;
							error_count++;

						}
					}
					
				}

				if(ok)
				{
					lookupSymbol->isdefined = true;
				}

				
			} 
			else //already defined
			{
				errorFile<<"Line# "<<$1->start_line<<": Multiple defination for '"<<lookupSymbol->getName()<<"'"<<endl;
				error_count++;
			}
		}
		else 
		{ 
			errorFile<<"Line# "<<$2.helper->start_line<<": '"<<lookupSymbol->getName()<<"' redeclared as different kind of symbol"<<endl;
			error_count++;
		}
		delete symbol;
	}
				
} 	
	compound_statement 
		{
			$$ = new Helper("func_definition : type_specifier ID LPAREN parameter_list RPAREN compound_statement ");


			$$ -> start_line = $1->start_line;
			$$ -> end_line = $7->end_line;
			
			$$ -> add($1);
            $$ -> add($2.helper);
            $$ -> add($3);
            $$ -> add($4);
            $$ -> add($5);
            $$ -> add($7);
            

			/* check return type and return statement */

			if($1 -> type == "VOID" && $7 -> returnType != "")
			{
				errorFile<<"Line# "<<$1->start_line<<": retrun type is void but func is returning '"<<$7->returnType<<"'"<<endl;
				error_count++;
			}
			else if($1 -> type == "INT" && $7 -> returnType == "FLOAT")
			{
				errorFile<<"Line# "<<$1->start_line<<": Warning: possible loss of data in returning of FLOAT to INT"<<endl;
				error_count++;
			}
			else if($1 -> type != "VOID" && $7 -> returnType == "")
			{
				errorFile<<"Line# "<<$1->start_line<<": Warning: no data is returned from function"<<endl;
				error_count++;
			}  


			if(!isMain && $1->type == "VOID")
			{
				if(var_count != 0)
				{
					tempFile<<"\tADD SP,"<<var_count*2<<endl;
				}
				
				tempFile<<"\tPOP BP"<<endl;
				tempFile << "\tRET"<<endl;
			}

			else if (isMain && $1->type == "VOID")
			{
				tempFile<<"\tPOP BP"<<endl;
				tempFile << "\tMOV AH,4CH" << endl;
				tempFile << "\tINT 21H" << endl;
			}


			tempFile<<$2.symbol->getName()<<" ENDP"<<endl;
			

			logFile<<$$->name<<endl;
			
		}
		| type_specifier ID LPAREN RPAREN 
		{
			  	
				SymbolInfo* symbol = new SymbolInfo($2.symbol->getName(),"FUNCTION");

				var_count = 0;
				
				symbol->additionalType = $1->type;
				symbol->isdefined = true;

				tempFile << $2.symbol->getName() << " PROC" <<endl;

				
				if ($2.symbol->getName()  == "main")
				{
					
					isMain = true;
		
					tempFile << "\tMOV AX,@DATA"<<endl;
					tempFile<<"\tMOV DS,AX"<<endl;
				}
				else
				{
					isMain = false;
					
				}

				tempFile<<"\tPUSH BP"<<endl; // SAVE BP 
				tempFile<<"\tMOV BP,SP"<<endl;

				if(symboltable->Insert(symbol))
				{
					//successfully inserted
				}
				else
				{
					SymbolInfo* lookupSymbol = symboltable->lookup(symbol->getName());

					if(lookupSymbol->getType() == "FUNCTION")
					{
						if(lookupSymbol->isdefined == false) //declared but not defined
						{

							bool ok = true;

							
							if(temp_parameter.size() != lookupSymbol->param_type.size())
							{
								errorFile<<"Line# "<<$1->start_line<<": Conflicting types for '"<<lookupSymbol->getName()<<"'"<<endl;
								ok = false;
								error_count++;
							}

							if(lookupSymbol->additionalType != $1->type)
							{
								ok = false;

								errorFile<<"Line# "<<$1->start_line<<": Conflicting types for '"<<lookupSymbol->getName()<<"'"<<endl;
								error_count++;
							}

							if(ok)
							{
								for(int i=0;i<lookupSymbol->param_type.size();i++) // check parameter type
								{
									if(temp_parameter[i].symbol->getType() != lookupSymbol->param_type[i])
									{
										errorFile<<"Line# "<<$1->start_line<<": Conflicting types for '"<<lookupSymbol->getName()<<"' parameter "<<temp_parameter[i].symbol->getName()<<endl;
										ok = false;
										error_count++;

									}
								}
								
							}

							if(ok)
							{
								lookupSymbol->isdefined = true;
								
								

								
							}							
						}
						else
						{
							errorFile<<"Line# "<<$1->start_line<<": Multiple defination for '"<<lookupSymbol->getName()<<"'"<<endl;
							error_count++;
						}
					}
					else
					{
						errorFile<<"Line# "<<$2.helper->start_line<<": '"<<lookupSymbol->getName()<<"' redeclared as different kind of symbol"<<endl;
						error_count++;
					}

					delete symbol;

				}
				
		} 
		compound_statement
		{
			$$ = new Helper("func_definition : type_specifier ID LPAREN RPAREN compound_statement ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $6->end_line;
			
			$$ -> add($1);
            $$ -> add($2.helper);
            $$ -> add($3);
            $$ -> add($4);
            $$ -> add($6);
           


			/* check return type and return statement */

			if($1 -> type == "VOID" && $6 -> returnType != "")
			{
				errorFile<<"Line# "<<$1->start_line<<": retrun type is void but func is returning '"<<$6->returnType<<"'"<<endl;
				error_count++;
			}
			else if($1 -> type == "INT" && $6 -> returnType == "FLOAT")
			{
				errorFile<<"Line# "<<$1->start_line<<": Warning: possible loss of data in returning of FLOAT to INT"<<endl;
				error_count++;
			}
			else if($1 -> type != "VOID" && $6 -> returnType == "")
			{
				errorFile<<"Line# "<<$1->start_line<<": Warning: no data is returned from function"<<endl;
				error_count++;
			}  

			
			if(!isMain && $1->type == "VOID")
			{
				tempFile<<"\tPOP BP"<<endl;
				tempFile << "\tRET"<<endl;
			}
			else if (isMain && $1->type == "VOID")
			{
				tempFile<<"\tPOP BP"<<endl;
				tempFile << "\tMOV AH,4CH" << endl;
				tempFile << "\tINT 21H" << endl;
			}

			tempFile<<$2.symbol->getName()<<" ENDP"<<endl;

			
			logFile<<$$->name<<endl;
		}
 		;				


parameter_list : parameter_list COMMA type_specifier ID
		{
			$$ = new Helper("parameter_list : parameter_list COMMA type_specifier ID ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $4.helper->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
            $$ -> add($3);
            $$ -> add($4.helper);
       


			SymbolInfo* symbol = new SymbolInfo($4.symbol->getName(),$3->type);

			temp_value.symbol = symbol;
			temp_value.helper =  $4.helper;

			temp_parameter.push_back(temp_value);

			logFile<<$$->name<<endl;

	
		}
		| parameter_list COMMA type_specifier
		{
			$$ = new Helper("parameter_list : parameter_list COMMA type_specifier ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $3->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
            $$ -> add($3);



			SymbolInfo* symbol = new SymbolInfo("",$3->type);

			temp_value.symbol = symbol;
			temp_value.helper =  $3;

			temp_parameter.push_back(temp_value);
			logFile<<$$->name<<endl;

			
		}
 		| type_specifier ID
		{
			$$ = new Helper("parameter_list : type_specifier ID ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $2.helper->end_line;
			
			$$ -> add($1);
            $$ -> add($2.helper);
            



			SymbolInfo* symbol = new SymbolInfo($2.symbol->getName(),$1->type);


			temp_value.symbol = symbol;
			temp_value.helper =  $2.helper;

			temp_parameter.push_back(temp_value);
			
			logFile<<$$->name<<endl;
		}
		| type_specifier
		{
			$$ = new Helper("parameter_list : type_specifier ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);

			SymbolInfo* symbol = new SymbolInfo("",$1->type);
			temp_value.symbol = symbol;
			temp_value.helper =  $1;

			temp_parameter.push_back(temp_value);
			
			logFile<<$$->name<<endl;
		}
 		;

 		
compound_statement : LCURL ENTER_SCOPE statements RCURL
			{
				
				$$ = new Helper("compound_statement : LCURL statements RCURL ");

				$$ -> start_line = $1->start_line;
				$$ -> end_line = $4->end_line;
				
				$$ -> add($1);
                $$ -> add($3);
                $$ -> add($4);


				
				
				$$ -> returnType = $3 -> returnType;
				



				
				logFile<<$$->name<<endl;

				symboltable -> Print_All_Scope_Table();

			

				symboltable -> Exit_Scope();

				

			}
 		    | LCURL ENTER_SCOPE RCURL
			{
				
				$$ = new Helper("compound_statement : LCURL RCURL ");

				$$ -> start_line = $1->start_line;
				$$ -> end_line = $3->end_line;
				
				$$ -> add($1);
               
                $$ -> add($3);

				logFile<<$$->name<<endl;

				symboltable -> Print_All_Scope_Table();


				symboltable -> Exit_Scope();
			
			}
 		    ;

ENTER_SCOPE : {

			symboltable -> Enter_Scope();

			int size = temp_parameter.size();

			param_size = size;

			for(int i=0;i<temp_parameter.size();i++)
			{
				
				SymbolInfo* symbol = new SymbolInfo(temp_parameter[i].symbol->getName(),temp_parameter[i].symbol->getType());

				symbol -> accessName = temp_parameter[i].symbol->accessName;
				symbol -> isglobal = temp_parameter[i].symbol->isglobal;

				
				int offset = 4 + (size - i - 1) * 2;


				
				symbol->accessName = "[BP +" + to_string(offset) + "]";

				int line_count = temp_parameter[i].helper->start_line;
				
				

				if(symbol->getName() == "")
				{
					errorFile<<"Line# "<<line_count<<": No variable declared after type_specifier"<<symbol->getType()<<"'"<<endl;
					error_count++;
				}
				else
				{
					if(symboltable->Insert(symbol))
					{
						//successfully inserted

						//symboltable->addVarCount(1);
					}
					else
					{
						
						errorFile<<"Line# "<<line_count<<": Redefinition of parameter '"<<temp_parameter[i].symbol->getName()<<"'"<<endl;
						error_count++;

						delete symbol;
					}
				}
				
			}

			temp_parameter.clear();
}
;

var_declaration : type_specifier declaration_list SEMICOLON 
{
		
		$$ = new Helper("var_declaration : type_specifier declaration_list SEMICOLON ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $3->end_line;
		
		$$ -> add($1);
        $$ -> add($2);
        $$ -> add($3);

		$$ ->type = $1 -> type;



		/* add all variables to symboltable */
		
		for(int i=0;i<temp_variable.size();i++)
		{

			
			SymbolInfo* symbol = new SymbolInfo(temp_variable[i].symbol->getName(),temp_variable[i].symbol->getType());

			symbol -> accessName = temp_variable[i].symbol->accessName;
			symbol -> isglobal = temp_variable[i].symbol->isglobal;



			if($1 ->type == "VOID")
			{
				errorFile<<"Line# "<<temp_variable[i].helper->start_line<<": Variable or field '"<<temp_variable[i].symbol->getName()<<"' declared void"<<endl;
				error_count++;
			}
			else // try insert to symbol table
			{
				if(symbol->getType() == "")
				{
					symbol->setType($1 -> type);
				}
				else if(symbol->getType() == "ARRAY")
				{
					symbol -> additionalType = $1 -> type;
				}



				if(symboltable->Insert(symbol))
				{
					//successfully inserted
				}
				else  //already inserted in symbol table
				{
					SymbolInfo* lookupSymbol = symboltable->lookup(symbol->getName());

					if(lookupSymbol->getType() != "ARRAY") 
					{
						if(lookupSymbol->getType() != symbol->getType())
						{
							errorFile<<"Line# "<<temp_variable[i].helper->start_line<<": Conflicting types for '"<<lookupSymbol->getName()<<"'"<<endl;
							error_count++;
						}
						else
						{
							errorFile<<"Line# "<<temp_variable[i].helper->start_line<<": Multiple declaration for '"<<lookupSymbol->getName()<<"'"<<endl;
							error_count++;
						}
					}
					else
					{
						if(lookupSymbol->additionalType != symbol->additionalType)
						{
							errorFile<<"Line# "<<temp_variable[i].helper->start_line<<": Conflicting types for '"<<lookupSymbol->getName()<<"'"<<endl;
							error_count++;
						}
						else
						{
							errorFile<<"Line# "<<temp_variable[i].helper->start_line<<": Multiple declaration for '"<<lookupSymbol->getName()<<"'"<<endl;
							error_count++;
						}
					}

					delete symbol;
				}
			}

			
		}

		temp_variable.clear();

		logFile<<$$->name<<endl;
}
;
 		 
type_specifier : INT 
		{
			$$ = new Helper("type_specifier : INT ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
           

			$$ -> type = "INT";

			logFile<<$$->name<<endl;



		}
 		| FLOAT
		{
			$$ = new Helper("type_specifier : FLOAT ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
          

			$$ -> type = "FLOAT";

			logFile<<$$->name<<endl;
			 
		}
 		| VOID
		{
			$$ = new Helper("type_specifier : VOID ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
           
          

			$$ -> type = "VOID";


			logFile<<$$->name<<endl;
		}
 		;
 		
declaration_list : declaration_list COMMA ID 
			{
				$$ = new Helper("declaration_list : declaration_list COMMA ID ");
				
				$$ -> start_line = $1->start_line;
				$$ -> end_line = $3.helper->end_line;
				
				$$ -> add($1);
                $$ -> add($2);
                $$ -> add($3.helper);
             
				
				//assembly

				if(symboltable->currScope->scopeNumber == 1)
				{
					
					tempFile<<"#\t"<<$3.symbol->getName()<<" DW 0"<<endl;
					$3.symbol->accessName = $3.symbol->getName();
					$3.symbol->isglobal = true;
			
				}
				else
				{
					
					var_count++;

					
					$3.symbol->accessName = "[BP-" + to_string(2 * var_count) + "]";


					tempFile << "\tSUB SP,2\t" <<endl;

					$3.symbol->isglobal = false;
					
					
				}


				SymbolInfo* symbol = $3.symbol;
				symbol->setType("");  					

				temp_value.symbol = symbol;
				temp_value.helper =  $3.helper;

				temp_variable.push_back(temp_value);

			
				logFile<<$$->name<<endl;
				
				
			}

 		  | declaration_list COMMA ID LSQUARE CONST_INT RSQUARE 
			{
				$$ = new Helper("declaration_list : declaration_list COMMA ID LSQUARE CONST_INT RSQUARE ");

				$$ -> start_line = $1->start_line;
				$$ -> end_line = $6->end_line;
				
				$$ -> add($1);
                $$ -> add($2);
                $$ -> add($3.helper);
                $$ -> add($4);
                $$ -> add($5.helper);
                $$ -> add($6);


				$3.symbol->setType("ARRAY");
				$3.symbol->arraySize = $5.symbol->getName(); //assembly

				


				if(symboltable->currScope->scopeNumber == 1)
				{
					
					tempFile<<"#\t"<<$3.symbol->getName()<<" DW "<<$3.symbol->arraySize<<" DUP(0000H)"<<endl;
					$3.symbol->accessName = $3.symbol->getName()+"+SI";
					
					$3.symbol->isglobal = true;
				
				}
				else
				{
					
					int arrSize = stoi($3.symbol->arraySize);

					
					int array_start = (var_count + arrSize) * 2;

					

					var_count += arrSize;

					string baseAddress = "[BP-"+ to_string(array_start) + "+SI]";

					$3.symbol->accessName = baseAddress;

					$3.symbol->isglobal = false;

					$3.symbol->arrayStartIndex = array_start;

					if(arrSize != 0)
					{
						tempFile << "\tSUB SP," << (arrSize * 2) <<endl;
					}
					
				}

				SymbolInfo* symbol = $3.symbol;
				symbol->setType("ARRAY");
				
				temp_value.symbol = symbol;
				temp_value.helper =  $3.helper;
			   

				temp_variable.push_back(temp_value);
				
				logFile<<$$->name<<endl;
			}
 		  | ID 
		  {
			 	$$ = new Helper("declaration_list : ID ");

			 	$$ -> start_line = $1.helper->start_line;
				$$ -> end_line = $1.helper->end_line;
				
				$$ -> add($1.helper);
    

				
				if(symboltable->currScope->scopeNumber == 1)
				{
					
					tempFile<<"#\t"<<$1.symbol->getName()<<" DW 0"<<endl;
					$1.symbol->accessName = $1.symbol->getName();
					$1.symbol->isglobal = true;
				
				}
				else
				{
					var_count++;
					$1.symbol->accessName = "[BP-" + to_string(var_count * 2) + "]";
					$1.symbol->isglobal = false;
					tempFile << "\tSUB SP,2\t" <<endl;
					
				}

				SymbolInfo* symbol = $1.symbol;
				symbol->setType("");
				temp_value.symbol = symbol;
				temp_value.helper =  $1.helper;

			

				temp_variable.push_back(temp_value);


				logFile<<$$->name<<endl;
			 
		  }
 		  | ID LSQUARE CONST_INT  RSQUARE 
		  {
				$$ = new Helper("declaration_list : ID LSQUARE CONST_INT RSQUARE ");


				$$ -> start_line = $1.helper->start_line;
				$$ -> end_line = $4->end_line;
				
				$$ -> add($1.helper);
                $$ -> add($2);
                $$ -> add($3.helper);
                $$ -> add($4);

				$1.symbol->setType("ARRAY");
				$1.symbol->arraySize = $3.symbol->getName(); //assembly

			

				if(symboltable->currScope->scopeNumber == 1)
				{
					
					tempFile<<"#\t"<<$1.symbol->getName()<<" DW "<<$1.symbol->arraySize<<" DUP(0000H)"<<endl;
					$1.symbol->accessName = $1.symbol->getName()+"+SI";
					$1.symbol->isglobal = true;
						
				}
				else
				{
					
					int arrSize = stoi($1.symbol->arraySize);
				
					int array_start = (var_count + arrSize) * 2;

				
					var_count += arrSize;

					string baseAddress = "[BP-"+ to_string(array_start) + "+SI]";

					$1.symbol->accessName = baseAddress;

			
					$1.symbol->isglobal = false;

					$1.symbol->arrayStartIndex = array_start;
					

					if(arrSize != 0)
					{
						tempFile << "\tSUB SP," << (arrSize * 2) <<endl;
					}
					
	
				}

				SymbolInfo* symbol = $1.symbol;
				symbol->setType("ARRAY");
				
				temp_value.symbol = symbol;
				temp_value.helper =  $1.helper;
				temp_variable.push_back(temp_value);

				

				logFile<<$$->name<<endl;

		  }
 		  ;
 		  
statements : statement
		{
			$$ = new Helper("statements : statement ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
       

			$$ -> returnType = $1 -> returnType;

			$$ -> label = $1 -> label;

			logFile<<$$->name<<endl;
		}
	   | statements statement
	   {
		   $$ = new Helper("statements : statements statement ");

		  	$$ -> start_line = $1->start_line;
			$$ -> end_line = $2->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
      

		   $$ -> returnType = $2 -> returnType;

		   $$ -> label = $2->label;

		   logFile<<$$->name<<endl;
	   }
	   ;
	   
statement : var_declaration
		{
		    $$ = new Helper("statement : var_declaration ");
  
		    $$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
           

		   logFile<<$$->name<<endl;
		
		}
	  | expression_statement
	   {
		    $$ = new Helper("statement : expression_statement ");

		    $$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
         

		   logFile<<$$->name<<endl;
		 
	   }
	  | compound_statement
	  {
		   $$ = new Helper("statement : compound_statement ");

		    $$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;

			$$ -> add($1);
       

		   logFile<<$$->name<<endl;
	  }
	  | FOR LPAREN 
	  {
		varStack.push(var_count);

	  } expression_statement
	  {

		string label = newLabel();
		stack_.push(label);
		tempFile<<label<<":"<<endl;

	  } expression_statement
	  {

		

		string for_end_label = newLabel();
		string for_statement = newLabel();
		string for_update = newLabel();

		tempFile<<"\tCMP AX,0"<<endl;
		tempFile<<"\tJE "<<for_end_label<<endl;
		tempFile<<"\tJMP "<<for_statement<<endl;
		tempFile<<for_update<<":"<<endl;

		stack_.push(for_end_label);
		stack_.push(for_statement);
		stack_.push(for_update);

		

	  } expression RPAREN 
	  {
		

		string for_update = stack_.top();
		stack_.pop();
		string for_statement = stack_.top();
		stack_.pop();
		string for_end_label = stack_.top();
		stack_.pop();
		string for_condition = stack_.top();
		stack_.pop();

		tempFile<<"\tJMP "<<for_condition<<endl;
		tempFile<<for_statement<<":"<<endl;

		stack_.push(for_end_label);
		stack_.push(for_update);
	  }
	   statement
	  {
		    $$ = new Helper("statement : FOR LPAREN expression_statement expression_statement expression RPAREN statement ");


			$$ -> start_line = $1->start_line;
			$$ -> end_line = $11->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
            $$ -> add($4);
            $$ -> add($6);

          
            $$ -> add($8);
			$$ -> add($9);
            $$ -> add($11);


			string for_update = stack_.top();
			stack_.pop();
			string for_end_label = stack_.top();
			stack_.pop();

			

			if(var_count-varStack.top()!=0)
			{
				tempFile<<"\tADD SP,"<<(var_count-varStack.top())*2<<endl;
				var_count = varStack.top();
				
			}
			varStack.pop();

			tempFile<<"\tJMP "<<for_update<<endl;
			tempFile<<for_end_label<<":"<<endl;

			logFile<<$$->name<<endl;
			

		   
	  }
	  | IF LPAREN expression RPAREN IF_COMMON  statement IF_END  %prec LOWER_THAN_ELSE
	  {
			$$ = new Helper("statement : IF LPAREN expression RPAREN statement ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $6->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
            $$ -> add($3);
            $$ -> add($4);
            $$ -> add($6);

	
			string label = stack_.top();
			stack_.pop();


				
	

			tempFile<<label<<":"<<endl;

			logFile<<$$->name<<endl;
		   
	  }
	  | IF LPAREN expression RPAREN IF_COMMON  statement  IF_END ELSE 
	  {
		char* end_label = newLabel();
		tempFile<<"\tJMP "<<end_label<<endl;

		string label_else = stack_.top();
		stack_.pop();

	
		
		tempFile<<label_else<<":"<<endl;

		stack_.push(end_label);
		varStack.push(var_count);



	  } statement
	  {
			$$ = new Helper("statement : IF LPAREN expression RPAREN statement ELSE statement ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $10->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
            $$ -> add($3);
            $$ -> add($4);
			//$$ -> add($5);
            $$ -> add($6);
			//$$ -> add($7);
      
            $$ -> add($10);
       

		
			string end_label = stack_.top();
			stack_.pop();


			if(var_count-varStack.top()!=0)
			{
				tempFile<<"\tADD SP,"<<(var_count-varStack.top())*2<<endl;
				var_count = varStack.top();
			}

			varStack.pop();
			

			tempFile<<end_label<<":"<<endl;

			logFile<<$$->name<<endl;
	  }
	  | WHILE LPAREN 
	  {
		string label = newLabel();
		tempFile<<label<<":"<<endl;
		stack_.push(label);
		varStack.push(var_count);
	  }
	  expression RPAREN
	  {
			string end_label = newLabel();
			tempFile<<"\tCMP AX,0"<<endl;
			tempFile<<"\tJE "<< end_label<<endl;
			
			stack_.push(end_label);
			
	  }
	   statement
	  {
			$$ = new Helper("statement : WHILE LPAREN expression RPAREN statement ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $7->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
            $$ -> add($4);
            $$ -> add($5);
            $$ -> add($7);


			string end_label = stack_.top();
			stack_.pop();
			string cond_label = stack_.top();
			stack_.pop();

			if(var_count-varStack.top()!=0)
			{
				tempFile<<"\tADD SP,"<<(var_count-varStack.top())*2<<endl;
				var_count = varStack.top();
			}

			tempFile<<"\tJMP "<<cond_label<<endl;
			tempFile<<end_label<<":"<<endl;
			

			logFile<<$$->name<<endl;
		
	  }
	  | PRINTLN LPAREN ID RPAREN SEMICOLON 
	  {
		 	$$ = new Helper("statement : PRINTLN LPAREN ID RPAREN SEMICOLON ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $5->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
            $$ -> add($3.helper);
            $$ -> add($4);
            $$ -> add($5);

			SymbolInfo* lookupSymbol = symboltable->lookup($3.symbol->getName());
			tempFile<<"\tMOV AX,"<<lookupSymbol->accessName<<endl;
			tempFile<<"\tCALL println"<<endl;

			logFile<<$$->name<<endl;
	  }
	  | RETURN expression SEMICOLON
	  {
			$$ = new Helper("statement : RETURN expression SEMICOLON ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $3->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
            $$ -> add($3);
           

			$$ -> returnType = $2 -> type;


	
			if(var_count !=0)
			{
				tempFile<<"\tADD SP,"<<to_string(var_count * 2)<<endl;
			}
			

			if (isMain)
			{
				tempFile<<"\tPOP BP"<<endl;
				tempFile << "\tMOV AH,4CH" << endl;
				tempFile << "\tINT 21H" << endl;
			}
			else{
				
				tempFile<<"\tPOP BP"<<endl;
				tempFile << "\tRET"<<endl;
				
			}

			logFile<<$$->name<<endl;
	  }
	  ;

IF_COMMON : 
{
	$$ = new Helper("IF_COMMON : ");
	char* label = newLabel();
	tempFile<<"\tCMP AX,0"<<endl;
	tempFile<<"\tJE "<<label<<endl;

	stack_.push(label);

	varStack.push(var_count);
	
};

IF_END :
{
		$$ = new Helper("IF_END : ");
		if(var_count-varStack.top()!=0)
		{
			tempFile<<"\tADD SP,"<<(var_count-varStack.top())*2<<endl;
			var_count = varStack.top();
		}

		varStack.pop();
}



expression_statement : SEMICOLON
			{
				$$ = new Helper("expression_statement : SEMICOLON ");

				$$ -> start_line = $1->start_line;
				$$ -> end_line = $1->end_line;
				
				$$ -> add($1);
                

				logFile<<$$->name<<endl;
				
			}		
			| expression SEMICOLON 
			{
				$$ = new Helper("expression_statement : expression SEMICOLON ");

				$$ -> start_line = $1->start_line;
				$$ -> end_line = $2->end_line;
				
				$$ -> add($1);
                $$ -> add($2);
             

				logFile<<$$->name<<endl;
				
			}
			;
	  
variable : ID 
	 {
		
		$$ = new Helper("variable : ID ");

		$$ -> start_line = $1.helper->start_line;
		$$ -> end_line = $1.helper->end_line;
		
		$$ -> add($1.helper);

		SymbolInfo* lookupSymbol = symboltable->lookup($1.symbol->getName());

		if(lookupSymbol == nullptr)
		{
			
			errorFile<<"Line# "<<$1.helper->start_line<<": Undeclared variable '"<<$1.symbol->getName()<<"'"<<endl;
			error_count++;
		}
		else
		{
			
			$$ -> type = lookupSymbol->getType();


			$$ -> symbol = lookupSymbol;
			
		}

		logFile<<$$->name<<endl;
		
	 }		
	 | ID LSQUARE expression RSQUARE 
	 {
		$$ = new Helper("variable : ID LSQUARE expression RSQUARE ");

		$$ -> start_line = $1.helper->start_line;
		$$ -> end_line = $4->end_line;
		
        $$ -> add($1.helper);
        $$ -> add($2);
        $$ -> add($3);
        $$ -> add($4);


		SymbolInfo* lookupSymbol = symboltable->lookup($1.symbol->getName());

	

		if(lookupSymbol == nullptr)
		{
			
			errorFile<<"Line# "<<$1.helper->start_line<<": Undeclared array '"<<$1.symbol->getName()<<"'"<<endl;
			error_count++;
		}
		else if(lookupSymbol -> getType() != "ARRAY")
		{
			errorFile<<"Line# "<<$1.helper->start_line<<": '"<<lookupSymbol->getName()<<"' is not an array"<<endl;
			error_count++;
		}
		else 
		{
			
			if($3 -> type != "INT" && $3 -> type != "")
			{
				errorFile<<"Line# "<<$3->start_line<<": Array subscript is not an integer"<<endl;
				error_count++;
			}
			else
			{
				$$ -> type = lookupSymbol->additionalType;

				

				$$ -> symbol = lookupSymbol;


				tempFile<<"\tPUSH AX"<<endl;
				

			}
				

			
		}

		logFile<<$$->name<<endl;
	 }
	 ;
	 
 expression : logic_expression	
		{
			$$ = new Helper("expression : logic_expression ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
           


			$$ -> type = $1 -> type;

			logFile<<$$->name<<endl;
			
		}
	   | variable ASSIGNOP logic_expression
	   {
		
			$$ = new Helper("expression : variable ASSIGNOP logic_expression ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $3->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
            $$ -> add($3); 


			if($3 -> type == "VOID")
			{
				errorFile<<"Line# "<<$3->start_line<<": Void cannot be used in expression "<<endl;
				error_count++;
			}

			else if($1 -> type == "INT" && $3 -> type == "FLOAT")
			{
				errorFile<<"Line# "<<$2->start_line<<": Warning: possible loss of data in assignment of FLOAT to INT"<<endl;
				error_count++;
			}

			else if($1 -> type == "ARRAY" || $3->type == "ARRAY")
			{
				errorFile<<"Line# "<<$2->start_line<<": invalid array assignment "<<endl;
				error_count++;
			}


			//assembly
		

			if($1->symbol->getType() == "ARRAY")
			{
				tempFile<<"\t\POP SI"<<endl;
				tempFile<<"\tSHL SI,1"<<endl;
			}
			tempFile<<"\tMOV "<<$1->symbol->accessName<<","<<"AX"<<endl;
			
			logFile<<$$->name<<endl;
	   } 	
	   ;
			
logic_expression : rel_expression
		 {
			$$ = new Helper("logic_expression : rel_expression ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
            
			$$ -> type = $1 -> type;

			logFile<<$$->name<<endl;
		 }
		 | rel_expression LOGICOP 
		 {

			if($2.symbol->getName() == "||")
			{
				tempFile<<"\tCMP AX,0"<<endl;

				char* jumpLabel = newLabel(); 


				tempFile<<"\tJNE "<<jumpLabel<<endl; //go to Ax,1 label

				stack_.push(jumpLabel);

				char* equalzeroLabel = newLabel();

				tempFile<<"\tJMP "<<equalzeroLabel<<endl;

				tempFile<<equalzeroLabel<<":"<<endl;
			}
			else if($2.symbol->getName() == "&&")
			{
				tempFile<<"\tCMP AX,0"<<endl;

				char* jumpLabel = newLabel();

				tempFile<<"\tJNE "<<jumpLabel<<endl; //check the other one 
				
				char* equalzeroLabel = newLabel();


				stack_.push(equalzeroLabel);

				tempFile<<"\tJMP "<<equalzeroLabel<<endl;

				tempFile<<jumpLabel<<":"<<endl;
			}
			


		 }
		 rel_expression 
		 {
			$$ = new Helper("logic_expression : rel_expression LOGICOP rel_expression ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $4->end_line;
			
			$$ -> add($1);
            $$ -> add($2.helper);
            $$ -> add($4);

			

			if($1 -> type != "VOID" && $4->type != "VOID")
			{
				$$ -> type = "INT"; 
			}
			else
			{
				errorFile<<"Line# "<<$2.helper->start_line<<": Logic op can't be used with Void type "<<endl;
				error_count++;
			}
			
			if($2.symbol->getName() == "||")
			{

			
				tempFile<<"\tCMP AX,0"<<endl;

				string always_one_label = stack_.top();
				stack_.pop();

				tempFile<<"\tJNE "<<always_one_label<<endl;

				char* endLabel = newLabel();
				tempFile<<"\tJMP "<<endLabel<<endl;  // Ax,0 label

				tempFile<<always_one_label<<":"<<endl;
				tempFile<<"\tMOV AX,1"<<endl;

				char* exitLabel = newLabel();
				tempFile<<"\tJMP "<<exitLabel<<endl;

				tempFile<<endLabel<<":"<<endl;
				tempFile<<"\tMOV AX,0"<<endl;

				tempFile<<exitLabel<<":"<<endl;

			}
			else if($2.symbol->getName() == "&&")
			{

			
				tempFile<<"\tCMP AX,0"<<endl;

				char* endLabel = newLabel();

				tempFile<<"\tJNE "<<endLabel<<endl;

				string make_zero_label = stack_.top();
				stack_.pop(); 
				
				tempFile<<"\tJMP "<<make_zero_label<<endl;

				tempFile<<endLabel<<":"<<endl;
				tempFile<<"\tMOV AX,1"<<endl;
				char* exitLabel = newLabel();
				tempFile<<"\tJMP "<<exitLabel<<endl;


				tempFile<<make_zero_label<<":"<<endl;
				tempFile<<"\tMOV AX,0"<<endl;

				tempFile<<exitLabel<<":"<<endl;

			}


			
			logFile<<$$->name<<endl;
		 }	
		 ;
			
rel_expression : simple_expression
		{
			$$ = new Helper("rel_expression : simple_expression ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
           

			$$ -> type = $1->type;

			logFile<<$$->name<<endl;
		
		}
		| simple_expression RELOP
		{

			tempFile<<"\tPUSH AX"<<endl;
		}
		simple_expression	
		{
			$$ = new Helper("rel_expression : simple_expression RELOP simple_expression ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $4->end_line;
			
			$$ -> add($1);
            $$ -> add($2.helper);
            $$ -> add($4);


			if($1 -> type == "VOID" || $4 -> type == "VOID")
			{
				errorFile<<"Line# "<<$2.helper->start_line<<": Operand is void"<<endl;
				error_count++;
			}
			else if($1 -> type == "INT" && $4 -> type != "ARRAY")
			{

				$$ -> type = "INT";
			}

			else if($1 -> type == "FLOAT" && $4->type != "ARRAY")
			{

				$$ -> type = "INT";
			}
			else if($1 -> type == "ARRAY" && $4->type == "ARRAY")
			{
				$$ -> type = "INT";
				
			}
			else if($1 -> type == "ARRAY" && $4 -> type != "ARRAY")
			{
				
				errorFile<<"Line# "<<$4->start_line<<": both operand is not an array"<<endl;
				error_count++;
			}
			else if($4 -> type == "ARRAY" && $1 -> type != "ARRAY")
			{
				errorFile<<"Line# "<<$4->start_line<<": both operand is not an array"<<endl;
				error_count++;
				
			}

			char* trueLabel = newLabel();
			char* falseLabel = newLabel();
			char* endLabel = newLabel();

			tempFile<<"\tPOP DX"<<endl;

			tempFile<<"\tXCHG AX,DX"<<endl;
			tempFile<<"\tCMP AX,DX"<<endl;

			if($2.symbol->getName() == "<=")
			{
				tempFile<<"\tJLE "<<trueLabel<<endl;
				tempFile<<"\tJMP "<<falseLabel<<endl;
				
			}
			else if($2.symbol->getName() == "<")
			{
				tempFile<<"\tJL "<<trueLabel<<endl;
				tempFile<<"\tJMP "<<falseLabel<<endl;
				
			}
			else if($2.symbol->getName() == ">=")
			{
				tempFile<<"\tJGE "<<trueLabel<<endl;
				tempFile<<"\tJMP "<<falseLabel<<endl;
				
			}
			else if($2.symbol->getName() == ">")
			{
				tempFile<<"\tJG "<<trueLabel<<endl;
				tempFile<<"\tJMP "<<falseLabel<<endl;
				
			}
			else if($2.symbol->getName() == "!=")
			{
				tempFile<<"\tJNE "<<trueLabel<<endl;
				tempFile<<"\tJMP "<<falseLabel<<endl;
				
			}
			else if($2.symbol->getName() == "==")
			{
				tempFile<<"\tJE "<<trueLabel<<endl;
				tempFile<<"\tJMP "<<falseLabel<<endl;
				
			}

			tempFile<<trueLabel<<":"<<endl;
			tempFile<<"\tMOV AX,1"<<endl;
			tempFile<<"\tJMP "<<endLabel<<endl;

			tempFile<<falseLabel<<":"<<endl;
			tempFile<<"\tMOV AX,0"<<endl;

			tempFile<<endLabel<<":"<<endl;
			

			logFile<<$$->name<<endl;
		}
		;
				
simple_expression : term
		  {
			

			$$ = new Helper("simple_expression : term ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			 $$ -> add($1);
            
			 $$ -> type = $1 -> type;

			 logFile<<$$->name<<endl;

			 

		  }
		  | simple_expression ADDOP
		  {

			tempFile<<"\tPUSH AX"<<endl;

		  }
		  term
		  {
			
			
			
			 $$ = new Helper("simple_expression : simple_expression ADDOP term ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $4->end_line;
			
			$$ -> add($1);
            $$ -> add($2.helper);
            $$ -> add($4);
          


			 if($1 -> type == "ARRAY")
			 {
				 errorFile<<"Line# "<<$1->start_line<<"can't add an array"<<endl;
				 error_count++;
			 }
			 else if($4 -> type == "ARRAY")
			 {
				 errorFile<<"Line# "<<$4->start_line<<"can't add an array"<<endl;
				 error_count++;
			 }
			 else if($1 -> type == "VOID" || $4 -> type == "VOID")
			 {
				 errorFile<<"Line# "<<$2.helper->start_line<<"operands are void type"<<endl;
				 error_count++;
			 }
			 else if($1 -> type == "FLOAT" || $4 -> type == "FLOAT")
			 {
					$$ -> type = "FLOAT";
			 }
			 else if($1 -> type == "INT" && $4 -> type == "INT")
			 {
					$$ -> type = "INT";
			 }


			
			tempFile<<"\tPOP DX"<<endl;
			tempFile<<"\tXCHG AX,DX"<<endl;
		     if($2.symbol->getName() == "+")
			 	tempFile<<"\tADD AX,DX"<<endl;
			else if($2.symbol->getName() == "-")
				tempFile<<"\tSUB AX,DX"<<endl;

			 logFile<<$$->name<<endl;
		  } 
		  ;
					
term : unary_expression
	 {
		$$ = new Helper("term : unary_expression ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $1->end_line;
		
		$$ -> add($1);
    

		$$ -> type = $1 -> type;

		logFile<<$$->name<<endl;
		
	 }
     |  term MULOP 
	 {
		tempFile<<"\tPUSH AX"<<endl;
	 }
	 unary_expression
	 {
		$$ = new Helper("term : term MULOP unary_expression ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $4->end_line;
		
		$$ -> add($1);
        $$ -> add($2.helper);
        $$ -> add($4);
       

		if($2.symbol->getName() == "%" || $2.symbol->getName() == "/")
		{
			if($4 -> value == "0" || $4 -> value == "0.0")
			{
				errorFile<<"Line# "<<$4->start_line<<": Warning: division by zero i=0f=1Const=0"<<endl;
				error_count++;
			}

			else if($2.symbol -> getName() == "%")
			{
				if($1 -> type != "INT" || $4 -> type != "INT")
				{
					errorFile<<"Line# "<<$2.helper->start_line<<": Operands of modulus must be integers "<<endl;

					error_count++;
				}
				else
				{
					$$ -> type = "INT";


					tempFile<<"\tPOP CX"<<endl;
					tempFile<<"\tXCHG AX,CX"<<endl;
					tempFile<<"\tXOR DX,DX"<<endl;
					tempFile<<"\tCWD"<<endl;
					tempFile<<"\tIDIV CX"<<endl;
					tempFile<<"\tMOV AX,DX"<<endl;

					
				}
			}
			else if ($2.symbol -> getName() == "/")
			{
				if($1 -> type == "VOID" || $4 -> type == "VOID")
				{
					
					errorFile<<"Line# "<<$2.helper ->start_line<<": Void cannot be used in expression "<<endl;
					error_count++;
				}
				else if($1 -> type == "ARRAY" || $4 -> type == "ARRAY")
				{
					
					errorFile<<"Line# "<<$2.helper->start_line<<": operand is an array "<<endl;
					error_count++;
		
				}
				else if($1 -> type == "FLOAT" || $4 -> type == "FLOAT")
				{
					$$ -> type = "FLOAT";
				}
				else if( $1 -> type == "INT" && $4 -> type == "INT")
				{
					$$ -> type = "INT";
				}

					tempFile<<"\tPOP CX"<<endl;
					tempFile<<"\tXCHG AX,CX"<<endl;
					tempFile<<"\tXOR DX,DX"<<endl;
					tempFile<<"\tCWD"<<endl;
					tempFile<<"\tIDIV CX"<<endl;
					

				
			}
		}
		else
		{
			
			if($1 -> type == "VOID" || $4 -> type == "VOID")
			{
				
				errorFile<<"Line# "<<$2.helper ->start_line<<": Void cannot be used in expression "<<endl;
				error_count++;
			}
			else if($1 -> type == "ARRAY" || $4 -> type == "ARRAY")
			{
				
				errorFile<<"Line# "<<$2.helper ->start_line<<": invalid array operation "<<endl;
				error_count++;
			}
			else if($1 -> type == "FLOAT" || $4 -> type == "FLOAT")
			{
				$$ -> type = "FLOAT";
			}
			else if($1 -> type == "INT" && $4 -> type == "INT")
			{
				$$ -> type = "INT";
			}

			tempFile<<"\tPOP CX"<<endl;
			tempFile<<"\tCWD"<<endl;
			tempFile<<"\tIMUL CX"<<endl;
		}

		logFile<<$$->name<<endl;
	 }
     ;

unary_expression : ADDOP unary_expression
		{

			

			$$ = new Helper("unary_expression : ADDOP unary_expression ");

			$$ -> start_line = $1.helper->start_line;
			$$ -> end_line = $2->end_line;
			
			$$ -> add($1.helper);
            $$ -> add($2);
   


			if($2 -> type == "VOID")
			{
				errorFile<<"Line# "<<$2->start_line<<": Operand is void"<<endl;
			}
			else if($2 -> type == "ARRAY")
			{
				errorFile<<"Line# "<<$2->start_line<<": Operand is array"<<endl;
			}
			else
			{
				$$ -> type = $2 -> type;

				if($1.symbol->getName() == "-")
				{
					tempFile<<"\tNEG AX"<<endl;
					
				}
				
			}
			
			logFile<<$$->name<<endl;
		}
		 | NOT unary_expression 
		 {
			$$ = new Helper("unary_expression : NOT unary_expression ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $2->end_line;
			
			$$ -> add($1);
            $$ -> add($2);
           


			if($2 -> type == "VOID")
			{
				errorFile<<"Line# "<<$2->start_line<<": Operand is void"<<endl;
			}
			else if($2 -> type == "ARRAY")
			{
				errorFile<<"Line# "<<$2->start_line<<": Operand is array"<<endl;
			}
			else
			{
				$$ -> type = "INT";
			}

			logFile<<$$->name<<endl;
		 }
		 | factor
		 {
			$$ = new Helper("unary_expression : factor ");

			$$ -> start_line = $1->start_line;
			$$ -> end_line = $1->end_line;
			
			$$ -> add($1);
        


			$$ -> type = $1 -> type;

			$$ -> value = $1 -> value; // for checking 0

			logFile<<$$->name<<endl;
		
		 } 
		 ;
	
factor	: variable 
	{
		
		$$ = new Helper("factor : variable ");
		
		$$ -> start_line = $1->start_line;
		$$ -> end_line = $1->end_line;
		
		$$ -> add($1);

		$$ -> type = $1 -> type;

		
		if($1->symbol->getType() == "ARRAY")
		{
			
			tempFile<<"\tPOP SI"<<endl;
			tempFile<<"\tSHL SI,1"<<endl;

		}
		tempFile<<"\tMOV AX,"<<$1->symbol->accessName<<endl;

		logFile<<$$->name<<endl;
		
	}
	| ID LPAREN argument_list RPAREN 
	{
		$$ = new Helper("factor : ID LPAREN argument_list RPAREN ");
		

		$$ -> start_line = $1.helper->start_line;
		$$ -> end_line = $4->end_line;
		
		$$ -> add($1.helper);
        $$ -> add($2);
        $$ -> add($3);
        $$ -> add($4);

		


		SymbolInfo* lookupSymbol = symboltable->lookup($1.symbol -> getName());

		if(lookupSymbol == nullptr)
		{
			errorFile<<"Line# "<<$1.helper->start_line<<": Undeclared function '"<<$1.symbol->getName()<<"'"<<endl;
			error_count++;
		}
		else if(lookupSymbol -> getType()  != "FUNCTION")
		{
			errorFile<<"Line# "<<$1.helper->start_line<<": '"<<$1.symbol->getName()<<"' is not a function"<<endl;
			error_count++;
		}
		else
		{
			bool ok = true;

			for(int i=0;i<temp_arguments.size();i++)
			{
				if(temp_arguments[i] == "ERROR")
				{
					ok = false;
					break;
				}
			}

			if(ok)
			{
				if(temp_arguments.size() > lookupSymbol -> param_type.size())
				{
					errorFile<<"Line# "<<$3->start_line<<": Too many arguments to function '"<<lookupSymbol->getName()<<"'"<<endl;
					error_count++;
				}
				else if(temp_arguments.size() < lookupSymbol -> param_type.size())
				{
					errorFile<<"Line# "<<$3->start_line<<": Too few arguments to function '"<<lookupSymbol->getName()<<"'"<<endl;
					error_count++;
				}
				else
				{
					

					for(int i=0;i<temp_arguments.size();i++)
					{
						if(temp_arguments[i] != lookupSymbol->param_type[i])
						{
							errorFile<<"Line# "<<$3->start_line<<": Type mismatch for argument "<<i+1<<" of '"<<lookupSymbol->getName()<<"'"<<endl;
							error_count++;
						}
					}

					
					$$ -> type = lookupSymbol->additionalType;
					

				}
			}
			else
			{
				$$ -> type = lookupSymbol->additionalType;
			}
		}

		tempFile<<"\tCALL "<<$1.symbol->getName()<<endl;


		SymbolInfo* lookupSym =  symboltable->lookup($1.symbol->getName());

		if(lookupSym->param_type.size() != 0)
		{
			tempFile<<"\tADD SP,"<<lookupSym->param_type.size() * 2<<endl;
		}
		
		temp_arguments.clear();

		logFile<<$$->name<<endl;

	}
	| LPAREN expression RPAREN
	{
		$$ = new Helper("factor : LPAREN expression RPAREN ");

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $3->end_line;
		
		$$ -> add($1);
        $$ -> add($2);
        $$ -> add($3);

		$$ -> type = $2 -> type;

		logFile<<$$->name<<endl;

	}
	| CONST_INT 
	{
		$$ = new Helper("factor : CONST_INT ");
	
		$$ -> start_line = $1.helper->start_line;
		$$ -> end_line = $1.helper->end_line;
		
		$$ -> add($1.helper);
      

		

		$$ -> type = "INT";

		$$ -> value = $1.symbol->getName();

		logFile<<$$->name<<endl;

		
		tempFile<<"\tMOV AX,"<<$1.symbol->getName()<<endl;
		
		
	}
	| CONST_FLOAT
	{
		$$ = new Helper("factor : CONST_FLOAT ");

		$$ -> start_line = $1.helper->start_line;
		$$ -> end_line = $1.helper->end_line;
		
		$$ -> add($1.helper);
       

		$$ -> type = "FLOAT";

		$$ -> value = $1.symbol->getName();

		logFile<<$$->name<<endl;

		
		tempFile<<"\tMOV AX,"<<$1.symbol->getName()<<endl;


	}
	| variable INCOP 
	{
		$$ = new Helper("factor : variable INCOP ");
		

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $2->end_line;
		
		$$ -> add($1);
        $$ -> add($2);

		if($1 -> type == "ARRAY")
		{
			errorFile<<"Line# "<<$1->start_line<<": invalid array operation "<<endl;
			error_count++;
		}
		else
		{
			$$ -> type = $1 -> type;





			if($1->symbol->getType()=="ARRAY")
			{
				tempFile<<"\tPOP SI"<<endl;
				tempFile<<"\tSHL SI,1"<<endl;
			}

			tempFile<<"\tMOV AX,"<<$1->symbol->accessName<<endl;
			tempFile<<"\tPUSH AX"<<endl;
			tempFile<<"\tINC AX"<<endl;
			tempFile<<"\tMOV "<<$1->symbol->accessName<<",AX"<<endl;
			tempFile<<"\tPOP AX"<<endl;

		}

		logFile<<$$->name<<endl;
		
		
	}
	| variable  DECOP 
	{
		$$ = new Helper("factor : variable DECOP ");
		

		$$ -> start_line = $1->start_line;
		$$ -> end_line = $2->end_line;
		
		$$ -> add($1);
        $$ -> add($2);
     
		if($1 -> type == "ARRAY")
		{
			errorFile<<"Line# "<<$1->start_line<<": invalid array operation "<<endl;
			error_count++;
		}
		else
		{
			$$ -> type = $1 -> type;



			if($1->symbol->getType()=="ARRAY")
			{
				tempFile<<"\tPOP SI"<<endl;
				tempFile<<"\tSHL SI,1"<<endl;
			}

			tempFile<<"\tMOV AX,"<<$1->symbol->accessName<<endl;
			tempFile<<"\tPUSH AX"<<endl;
			tempFile<<"\tDEC AX"<<endl;
			tempFile<<"\tMOV "<<$1->symbol->accessName<<",AX"<<endl;
			tempFile<<"\tPOP AX"<<endl;
		}
			

		logFile<<$$->name<<endl;

	}
	;
	
argument_list : arguments
				{
					$$ = new Helper("argument_list : arguments ");

					$$ -> start_line = $1->start_line;
					$$ -> end_line = $1->end_line;
					
					$$ -> add($1);
               
					
					$$ -> parse_tree += "\n";
					$$ -> parse_tree += $1->parse_tree;

					logFile<<$$->name<<endl;

					
				}
			  | 
			  {
					$$ = new Helper("argument_list : ");

					$$ -> start_line = line_count;   //notice
					$$ -> end_line = line_count;
					
					

					logFile<<$$->name<<endl;


			  }
			  ;
	
arguments : arguments COMMA logic_expression
		   {
				$$ = new Helper("arguments : arguments COMMA logic_expression ");

				$$ -> start_line = $1->start_line;
				$$ -> end_line = $3->end_line;
				
				$$ -> add($1);
                $$ -> add($2);
                $$ -> add($3);

				if($3->type == "")
				{
					temp_arguments.push_back("ERROR");
				}
				else
					temp_arguments.push_back($3 -> type);

				logFile<<$$->name<<endl;
				
				tempFile<<"\tPUSH AX"<<endl;
			

		   }
	      | logic_expression
		  {
			 	$$ = new Helper("arguments : logic_expression ");

				$$ -> start_line = $1->start_line;
				$$ -> end_line = $1->end_line;
				
				$$ -> add($1);


				if($1->type == "")
				{
					temp_arguments.push_back("ERROR");
				}
				else
					temp_arguments.push_back($1 -> type);

				tempFile<<"\tPUSH AX"<<endl;

				logFile<<$$->name<<endl;
				
		  }
	      ;


%%
int main(int argc,char *argv[])
{
	

	if((fp=fopen(argv[1],"r"))==NULL)
	{
		printf("Cannot Open Input File.\n");
		exit(1);
	}

	parseFile.open("1905098_parsetree.txt");
	errorFile.open("1905098_error.txt"); 
	logFile.open("1905098_log.txt");
	tempFile.open("1905098_temp.txt");
	

	symboltable = new SymbolTable(11,&logFile);
	symboltable->Enter_Scope(); 


	
	yyin = fp;

	
	yyparse();
	
	
	//symboltable -> Print_All_Scope_Table();

	logFile<<"Total Lines: "<<line_count<<endl;
	logFile<<"Total Errors: "<<error_count<<endl;
	fclose(fp);

	delete symboltable;
	
	return 0;
}

