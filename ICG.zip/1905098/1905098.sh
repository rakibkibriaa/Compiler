#!/bin/bash

yacc -d -y 1905098.y 
echo 'Generated the parser C file as well the header file'
g++ -w -c -o y.o y.tab.c
echo 'Generated the parser object file'
flex 1905098.l
echo 'Generated the scanner C file'
#g++ -w -c -o l.o lex.yy.c
g++ -fpermissive -w -c -o l.o lex.yy.c
echo 'Generated the scanner object file'
g++ y.o l.o -o out
echo 'All ready, running'
./out input.c
